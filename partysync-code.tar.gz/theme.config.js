/** @type {const} */
const themeColors = {
  primary: { light: '#7C3AED', dark: '#A78BFA' },
  background: { light: '#FAFAFA', dark: '#0F0F14' },
  surface: { light: '#FFFFFF', dark: '#1A1A24' },
  foreground: { light: '#1A1A2E', dark: '#F0F0F5' },
  muted: { light: '#6B7280', dark: '#9CA3AF' },
  border: { light: '#E5E7EB', dark: '#2D2D3D' },
  success: { light: '#10B981', dark: '#34D399' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
