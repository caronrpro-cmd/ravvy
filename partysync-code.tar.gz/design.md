# PartySync — Design Document

## Vision

PartySync est une application mobile sociale et collaborative dédiée à l'organisation de soirées entre amis. Elle combine un réseau social privé, un organisateur d'événements et un outil collaboratif en temps réel avec une dimension sécurité. Cible : 18–35 ans.

---

## Screen List

### 1. Onboarding (3 écrans)
- **Slide 1** : Illustration festive + "Organisez vos soirées facilement"
- **Slide 2** : Illustration collaborative + "Collaborez en temps réel"
- **Slide 3** : Illustration sécurité + "Rentrez en sécurité" + bouton "Commencer"

### 2. Auth Screen
- Connexion / Inscription par email
- Boutons Google & Apple OAuth
- Formulaire : nom, username, email, mot de passe

### 3. Home (Feed)
- Header avec avatar utilisateur + nom + icône notifications
- Section "Prochaines soirées" : cartes horizontales scrollables
- Section "Mes groupes" : liste verticale avec aperçu (nom, membres, date)
- FAB (Floating Action Button) pour créer un groupe

### 4. Groups Tab
- Liste de tous les groupes (classiques + auto-destructibles)
- Badge pour groupes auto-destructibles avec countdown
- Barre de recherche en haut
- Filtres : Tous / Classiques / Temporaires

### 5. Create Screen (Modal)
- Choix du type : Groupe Classique ou Auto-Destructible
- Formulaire : nom, description, date, lieu, photo de couverture
- Pour auto-destructible : sélecteur date/heure d'expiration
- Ajout de membres depuis la liste d'amis

### 6. Group Hub (Page centrale d'un groupe)
- Header avec image de couverture, nom, date, lieu
- Barre de statut RSVP (présent/absent/peut-être)
- Grid de modules : Chat, Courses, Covoiturage, Album, Tâches, Localisation
- Liste des participants avec statuts
- Pour groupes auto-destructibles : timer de destruction visible

### 7. Chat Screen
- Messages texte avec bulles
- Réactions emoji sur messages
- Messages épinglés (bandeau en haut)
- Partage d'images et localisation
- Input bar avec bouton envoi + pièce jointe

### 8. Shopping List Screen
- Toggle Mode Liste / Mode Tricount
- **Mode Liste** : items avec attribution membre, statut, prix, total
- **Mode Tricount** : dépenses par utilisateur, calcul dettes, bilan

### 9. Carpool Screen
- Liste des conducteurs avec places disponibles
- Carte avec points de départ
- Bouton "Je conduis" / "Réserver une place"
- Détails : lieu départ, places, passagers

### 10. Album Screen
- Grille de photos/vidéos
- Upload depuis galerie
- Tags utilisateurs
- Bouton téléchargement avant destruction

### 11. Tasks Screen
- Liste de tâches avec checkboxes
- Attribution à un membre
- Priorité (couleur : vert/orange/rouge)
- Deadline affichée

### 12. Location Screen
- Carte avec positions des participants
- Toggle partage de localisation
- Bouton SOS / Urgence (rouge, proéminent)
- Mode soirée (tracking temporaire)

### 13. Notifications Tab
- Liste chronologique des notifications
- Types : RSVP, tâches, covoiturage, dépenses, rappels, destruction
- Swipe pour marquer comme lu

### 14. Profile Tab
- Photo de profil, nom, username, bio
- Statut (disponible, occupé, etc.)
- Section amis avec compteur
- Bouton QR code pour ajout d'amis
- Paramètres (dark mode, notifications, confidentialité)

### 15. Friends Management
- Liste d'amis avec recherche
- Ajout par username ou QR code
- Invitations reçues/envoyées
- Blocage / gestion permissions

### 16. Settings Screen
- Apparence (Dark/Light mode)
- Notifications (sourdine par groupe)
- Confidentialité (localisation, contacts)
- Compte (modifier profil, déconnexion)

### 17. AI Assistant (Premium)
- Interface chat avec l'assistant IA
- Suggestions : liste courses, playlist, budget, tâches, planning

---

## Primary Content & Functionality per Screen

| Screen | Content | Functionality |
|--------|---------|---------------|
| Home | Cartes événements, liste groupes | Navigation rapide, création groupe |
| Groups | Liste groupes avec badges | Filtrage, recherche, accès groupe |
| Group Hub | Infos événement, modules | RSVP, accès modules, gestion participants |
| Chat | Messages, réactions | Envoi messages, épingler, partage |
| Shopping | Items/dépenses | Ajout items, attribution, calcul dettes |
| Carpool | Conducteurs, carte | Proposer/réserver place |
| Album | Photos/vidéos | Upload, tag, téléchargement |
| Tasks | Tâches avec priorités | Créer, assigner, compléter |
| Location | Carte live | Partage position, SOS |
| Profile | Infos utilisateur | Modifier profil, gérer amis |

---

## Key User Flows

### Flow 1 : Créer une soirée
1. Utilisateur tape sur FAB "+" (Home) ou tab "Créer"
2. Choisit type de groupe (Classique / Auto-Destructible)
3. Remplit formulaire (nom, date, lieu, description)
4. Si auto-destructible : définit date/heure d'expiration
5. Ajoute des amis au groupe
6. Confirme → redirigé vers Group Hub

### Flow 2 : Gérer les courses
1. Depuis Group Hub → tape sur module "Courses"
2. Choisit Mode Liste ou Mode Tricount
3. Mode Liste : ajoute items, attribue à un membre, indique prix
4. Mode Tricount : ajoute dépenses, voit bilan automatique
5. Membres voient les mises à jour en temps réel

### Flow 3 : Organiser le covoiturage
1. Depuis Group Hub → tape sur module "Covoiturage"
2. Conducteur tape "Je conduis" → indique places et lieu départ
3. Passagers voient les voitures disponibles
4. Passager tape "Réserver" sur une voiture
5. Carte affiche les points de départ

### Flow 4 : Mode Urgence
1. Depuis l'écran Location → tape bouton SOS
2. Confirmation rapide (éviter faux positifs)
3. Position envoyée en temps réel au groupe
4. Notification push immédiate à tous les membres
5. Option contact d'urgence externe

### Flow 5 : Auto-destruction d'un groupe
1. Timer visible dans Group Hub
2. Notification 24h avant → option sauvegarder médias
3. Notification 1h avant → dernière chance
4. À l'expiration : suppression complète (messages, photos, données)
5. Confirmation de destruction aux membres

---

## Color Choices

### Palette principale
- **Primary** : `#7C3AED` (Violet vif — énergie festive, modernité)
- **Primary Light** : `#A78BFA` (Violet clair pour accents)
- **Secondary** : `#F59E0B` (Ambre — chaleur, convivialité)

### Palette fonctionnelle
- **Background Light** : `#FAFAFA`
- **Background Dark** : `#0F0F14`
- **Surface Light** : `#FFFFFF`
- **Surface Dark** : `#1A1A24`
- **Foreground Light** : `#1A1A2E`
- **Foreground Dark** : `#F0F0F5`
- **Muted Light** : `#6B7280`
- **Muted Dark** : `#9CA3AF`
- **Border Light** : `#E5E7EB`
- **Border Dark** : `#2D2D3D`

### Couleurs d'état
- **Success** : `#10B981` (Vert émeraude)
- **Warning** : `#F59E0B` (Ambre)
- **Error** : `#EF4444` (Rouge)
- **SOS** : `#DC2626` (Rouge vif pour urgence)

### Couleurs spéciales
- **Auto-Destruct Badge** : `#F97316` (Orange — timer destruction)
- **RSVP Present** : `#10B981`
- **RSVP Absent** : `#EF4444`
- **RSVP Maybe** : `#F59E0B`

---

## Navigation Structure

### Bottom Tab Bar (5 tabs)
1. **Accueil** (house.fill) — Feed des événements
2. **Groupes** (person.3.fill) — Liste des groupes
3. **Créer** (plus.circle.fill) — Création de groupe (modal)
4. **Notifications** (bell.fill) — Centre de notifications
5. **Profil** (person.fill) — Profil et paramètres

### Navigation Stack dans chaque tab
- Home → Group Hub → [Chat, Courses, Covoiturage, Album, Tâches, Location]
- Groups → Group Hub → [modules]
- Profile → Friends, Settings, QR Code

---

## Design Principles

1. **Mobile-first** : Tout est optimisé pour une utilisation à une main
2. **Feedback immédiat** : Chaque action a un retour visuel et haptique
3. **Hiérarchie claire** : Les informations importantes sont toujours visibles
4. **Fun mais fonctionnel** : Design moderne et coloré sans sacrifier l'utilisabilité
5. **Dark mode natif** : Transition fluide entre les modes
6. **Accessibilité** : Contrastes suffisants, tailles de texte lisibles
