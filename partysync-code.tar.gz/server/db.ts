import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  groups, InsertGroup,
  groupMembers, InsertGroupMember,
  chatMessages, InsertChatMessage,
  pushTokens, InsertPushToken,
  shoppingItems, InsertShoppingItem,
  expenses, InsertExpense,
  tasks, InsertTask,
  polls, InsertPoll,
  carpoolRides, InsertCarpoolRide,
  photos, InsertPhoto,
  friendships, InsertFriendship,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ===== USERS =====

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserProfile(userId: number, data: { username?: string; bio?: string; avatar?: string; status?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(users).set(data).where(eq(users.id, userId));
}

// ===== GROUPS =====

export async function createGroup(data: InsertGroup) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(groups).values(data);
  return result[0].insertId;
}

export async function getGroupByExternalId(externalId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(groups).where(eq(groups.externalId, externalId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserGroups(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const memberships = await db.select().from(groupMembers).where(eq(groupMembers.userId, userId));
  if (memberships.length === 0) return [];
  const groupIds = memberships.map((m) => m.groupId);
  const allGroups = await db.select().from(groups);
  return allGroups.filter((g) => groupIds.includes(g.id));
}

export async function deleteGroup(groupId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(groupMembers).where(eq(groupMembers.groupId, groupId));
  await db.delete(chatMessages).where(eq(chatMessages.groupId, groupId));
  await db.delete(groups).where(eq(groups.id, groupId));
}

// ===== GROUP MEMBERS =====

export async function addGroupMember(data: InsertGroupMember) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(groupMembers).values(data);
}

export async function getGroupMembers(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  const members = await db.select().from(groupMembers).where(eq(groupMembers.groupId, groupId));
  const memberDetails = [];
  for (const m of members) {
    const user = await getUserById(m.userId);
    if (user) {
      memberDetails.push({
        ...m,
        name: user.name,
        username: user.username,
        avatar: user.avatar,
      });
    }
  }
  return memberDetails;
}

export async function updateMemberRsvp(groupId: number, userId: number, rsvp: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(groupMembers)
    .set({ rsvp: rsvp as any })
    .where(and(eq(groupMembers.groupId, groupId), eq(groupMembers.userId, userId)));
}

// ===== CHAT MESSAGES =====

export async function addChatMessage(data: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(chatMessages).values(data);
}

export async function getGroupMessages(groupId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  const msgs = await db.select().from(chatMessages)
    .where(eq(chatMessages.groupId, groupId))
    .orderBy(desc(chatMessages.createdAt))
    .limit(limit);
  // Enrich with sender info
  const enriched = [];
  for (const msg of msgs.reverse()) {
    const sender = await getUserById(msg.senderId);
    enriched.push({
      ...msg,
      senderName: sender?.name || "Inconnu",
      senderAvatar: sender?.avatar || "",
      reactions: msg.reactions ? JSON.parse(msg.reactions) : [],
    });
  }
  return enriched;
}

export async function pinMessage(messageId: number, pinned: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(chatMessages).set({ isPinned: pinned }).where(eq(chatMessages.id, messageId));
}

// ===== PUSH TOKENS =====

export async function savePushToken(data: InsertPushToken) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Upsert: delete old token for this user, insert new
  await db.delete(pushTokens).where(eq(pushTokens.userId, data.userId));
  await db.insert(pushTokens).values(data);
}

export async function getPushTokensForGroup(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  const members = await db.select().from(groupMembers).where(eq(groupMembers.groupId, groupId));
  const tokens = [];
  for (const m of members) {
    const userTokens = await db.select().from(pushTokens).where(eq(pushTokens.userId, m.userId));
    tokens.push(...userTokens);
  }
  return tokens;
}

export async function getUserPushTokens(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pushTokens).where(eq(pushTokens.userId, userId));
}

// ===== SHOPPING ITEMS =====

export async function addShoppingItem(data: InsertShoppingItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(shoppingItems).values(data);
}

export async function getGroupShoppingItems(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(shoppingItems).where(eq(shoppingItems.groupId, groupId));
}

export async function updateShoppingItem(id: number, data: Partial<InsertShoppingItem>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(shoppingItems).set(data).where(eq(shoppingItems.id, id));
}

export async function deleteShoppingItem(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(shoppingItems).where(eq(shoppingItems.id, id));
}

// ===== EXPENSES =====

export async function addExpense(data: InsertExpense) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(expenses).values(data);
}

export async function getGroupExpenses(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(expenses).where(eq(expenses.groupId, groupId));
}

export async function deleteExpense(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(expenses).where(eq(expenses.id, id));
}

// ===== TASKS =====

export async function addTask(data: InsertTask) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(tasks).values(data);
}

export async function getGroupTasks(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks).where(eq(tasks.groupId, groupId));
}

export async function updateTask(id: number, data: Partial<InsertTask>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(tasks).set(data).where(eq(tasks.id, id));
}

export async function deleteTask(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(tasks).where(eq(tasks.id, id));
}

// ===== POLLS =====

export async function addPoll(data: InsertPoll) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(polls).values(data);
}

export async function getGroupPolls(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(polls).where(eq(polls.groupId, groupId));
}

export async function deletePoll(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(polls).where(eq(polls.id, id));
}

// ===== CARPOOL RIDES =====

export async function addCarpoolRide(data: InsertCarpoolRide) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(carpoolRides).values(data);
}

export async function getGroupCarpoolRides(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(carpoolRides).where(eq(carpoolRides.groupId, groupId));
}

export async function updateCarpoolRide(id: number, data: Partial<InsertCarpoolRide>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(carpoolRides).set(data).where(eq(carpoolRides.id, id));
}

export async function deleteCarpoolRide(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(carpoolRides).where(eq(carpoolRides.id, id));
}

// ===== PHOTOS =====

export async function addPhoto(data: InsertPhoto) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(photos).values(data);
}

export async function getGroupPhotos(groupId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(photos).where(eq(photos.groupId, groupId));
}

export async function deletePhoto(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(photos).where(eq(photos.id, id));
}

// ===== FRIENDSHIPS =====

export async function addFriendship(data: InsertFriendship) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(friendships).values(data);
}

export async function getUserFriends(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const friendships_data = await db.select().from(friendships)
    .where(and(eq(friendships.userId, userId)));
  const friendIds = friendships_data.map((f) => f.friendId);
  const friends = [];
  for (const id of friendIds) {
    const user = await getUserById(id);
    if (user) friends.push(user);
  }
  return friends;
}

export async function deleteFriendship(userId: number, friendId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(friendships)
    .where(and(eq(friendships.userId, userId), eq(friendships.friendId, friendId)));
}
