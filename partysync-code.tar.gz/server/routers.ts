import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // User profile
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return ctx.user;
    }),
    update: protectedProcedure
      .input(z.object({
        username: z.string().optional(),
        bio: z.string().optional(),
        avatar: z.string().optional(),
        status: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.updateUserProfile(ctx.user.id, input);
        return { success: true };
      }),
  }),

  // Groups
  groups: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserGroups(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        name: z.string().min(1),
        description: z.string().optional(),
        type: z.enum(["classic", "auto-destruct"]).default("classic"),
        coverImage: z.string().optional(),
        date: z.string().optional(),
        time: z.string().optional(),
        location: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const groupId = await db.createGroup({
          ...input,
          description: input.description ?? null,
          coverImage: input.coverImage ?? null,
          date: input.date ?? null,
          time: input.time ?? null,
          location: input.location ?? null,
          createdBy: ctx.user.id,
        });
        // Add creator as admin member
        await db.addGroupMember({
          groupId,
          userId: ctx.user.id,
          role: "admin",
          rsvp: "present",
        });
        return { id: groupId, externalId: input.externalId };
      }),
    get: protectedProcedure
      .input(z.object({ externalId: z.string() }))
      .query(async ({ input }) => {
        return db.getGroupByExternalId(input.externalId);
      }),
    members: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return db.getGroupMembers(input.groupId);
      }),
    updateRsvp: protectedProcedure
      .input(z.object({
        groupId: z.number(),
        rsvp: z.enum(["present", "absent", "maybe", "pending"]),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.updateMemberRsvp(input.groupId, ctx.user.id, input.rsvp);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteGroup(input.groupId);
        return { success: true };
      }),
  }),

  // Chat
  chat: router({
    messages: protectedProcedure
      .input(z.object({ groupId: z.number(), limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return db.getGroupMessages(input.groupId, input.limit);
      }),
    send: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        groupId: z.number(),
        text: z.string().optional(),
        type: z.enum(["text", "image", "location"]).default("text"),
        imageUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.addChatMessage({
          externalId: input.externalId,
          groupId: input.groupId,
          senderId: ctx.user.id,
          text: input.text ?? null,
          type: input.type,
          imageUrl: input.imageUrl ?? null,
        });
        return { success: true };
      }),
    pin: protectedProcedure
      .input(z.object({ messageId: z.number(), pinned: z.boolean() }))
      .mutation(async ({ input }) => {
        await db.pinMessage(input.messageId, input.pinned);
        return { success: true };
      }),
  }),

  // Shopping items
  shopping: router({
    list: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return db.getGroupShoppingItems(input.groupId);
      }),
    add: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        groupId: z.number(),
        name: z.string(),
        quantity: z.number().optional(),
        price: z.string().optional(),
        assignedTo: z.string().optional(),
        assignedToName: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.addShoppingItem({
          ...input,
          checked: false,
          addedBy: ctx.user.id,
        });
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({ id: z.number(), checked: z.boolean().optional(), assignedTo: z.string().optional() }))
      .mutation(async ({ input }) => {
        await db.updateShoppingItem(input.id, { checked: input.checked, assignedTo: input.assignedTo });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteShoppingItem(input.id);
        return { success: true };
      }),
  }),

  // Expenses
  expenses: router({
    list: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return db.getGroupExpenses(input.groupId);
      }),
    add: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        groupId: z.number(),
        description: z.string(),
        amount: z.string(),
        paidBy: z.string(),
        paidByName: z.string().optional(),
        splitBetween: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.addExpense(input);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteExpense(input.id);
        return { success: true };
      }),
  }),

  // Tasks
  tasks: router({
    list: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return db.getGroupTasks(input.groupId);
      }),
    add: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        groupId: z.number(),
        title: z.string(),
        assignedTo: z.string().optional(),
        assignedToName: z.string().optional(),
        priority: z.enum(["low", "medium", "high"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.addTask({
          ...input,
          priority: input.priority ?? "medium",
          completed: false,
          createdBy: ctx.user.id,
        });
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({ id: z.number(), completed: z.boolean().optional(), priority: z.string().optional() }))
      .mutation(async ({ input }) => {
        await db.updateTask(input.id, { completed: input.completed, priority: input.priority as any });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteTask(input.id);
        return { success: true };
      }),
  }),

  // Polls
  polls: router({
    list: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return db.getGroupPolls(input.groupId);
      }),
    add: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        groupId: z.number(),
        question: z.string(),
        options: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.addPoll({ ...input, createdBy: ctx.user.id });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deletePoll(input.id);
        return { success: true };
      }),
  }),

  // Carpool
  carpool: router({
    list: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return db.getGroupCarpoolRides(input.groupId);
      }),
    add: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        groupId: z.number(),
        driverName: z.string(),
        driverId: z.string(),
        departure: z.string().optional(),
        departureTime: z.string().optional(),
        totalSeats: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.addCarpoolRide({
          ...input,
          availableSeats: (input.totalSeats ?? 4) - 1,
          passengers: JSON.stringify([]),
        });
        return { success: true };
      }),
    update: protectedProcedure
      .input(z.object({ id: z.number(), passengers: z.string().optional(), availableSeats: z.number().optional() }))
      .mutation(async ({ input }) => {
        await db.updateCarpoolRide(input.id, { passengers: input.passengers, availableSeats: input.availableSeats });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCarpoolRide(input.id);
        return { success: true };
      }),
  }),

  // Photos
  photos: router({
    list: protectedProcedure
      .input(z.object({ groupId: z.number() }))
      .query(async ({ input }) => {
        return db.getGroupPhotos(input.groupId);
      }),
    add: protectedProcedure
      .input(z.object({
        externalId: z.string(),
        groupId: z.number(),
        uri: z.string(),
        uploadedBy: z.string().optional(),
        uploadedByName: z.string().optional(),
        caption: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.addPhoto({ ...input, likes: 0 });
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deletePhoto(input.id);
        return { success: true };
      }),
  }),

  // Push tokens
  push: router({
    register: protectedProcedure
      .input(z.object({
        token: z.string(),
        platform: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.savePushToken({
          userId: ctx.user.id,
          token: input.token,
          platform: input.platform ?? null,
        });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
