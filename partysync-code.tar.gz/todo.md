# PartySync TODO

- [x] Configuration thème et couleurs (violet/ambre)
- [x] Navigation Bottom Tab (5 tabs : Accueil, Groupes, Créer, Notifications, Profil)
- [x] Icon mappings dans icon-symbol.tsx
- [x] Écrans d'onboarding (3 slides)
- [x] Écran d'authentification (email + profil)
- [x] Écran Profil utilisateur (photo, nom, username, bio, statut)
- [x] Système d'amis (ajout, liste, QR code)
- [x] Écran Accueil / Feed (prochaines soirées, mes groupes)
- [x] Création de groupe (classique + auto-destructible)
- [x] Group Hub (page centrale avec modules)
- [x] Gestion des participants et RSVP
- [x] Sondages intégrés dans les groupes
- [x] Module Chat temps réel (messages, réactions, épinglés)
- [x] Module Liste de courses collaborative (mode liste + mode tricount)
- [x] Module Covoiturage (conducteurs, places, réservation)
- [x] Module Album photo collaboratif (upload, tags, grille)
- [x] Module Tâches & Organisation (création, attribution, priorités)
- [x] Module Localisation & Sécurité (carte, partage position, SOS)
- [x] Système de notifications
- [x] Écran Paramètres (dark mode, notifications, confidentialité)
- [x] Assistant IA (suggestions courses, budget, planning)
- [x] Auto-destruction des groupes temporaires
- [x] Logo et branding de l'application

- [x] Intégration ImagePicker pour album photo (vraies photos)
- [x] Intégration ImagePicker pour avatar profil
- [x] Connexion backend : authentification utilisateur
- [x] Connexion backend : synchronisation multi-appareils
- [x] Connexion backend : chat temps réel
- [x] Notifications push via serveur backend
- [x] Dates en format français JJ/MM/AAAA partout
- [x] Vérifier et corriger le module localisation (expo-location intégré)

- [x] Intégrer expo-maps pour carte interactive dans localisation
- [x] Système de thèmes de soirée avec templates prédéfinis (anniversaire, BBQ, jeux)
- [x] Partage de groupe par lien/QR code
- [x] Bouton quitter un groupe + annuler soirée (organisateur) avec notification
- [x] Covoiturage : un seul choix de voiture + possibilité de se retirer
- [x] Visuel courses : voir qui prend quoi
- [x] Sondages : retirer sa réponse + supprimer sondage (organisateur)
- [x] Connexion OAuth multi-providers (Instagram, Gmail, Apple)
- [x] Personnaliser la bannière de l'événement avec une photo
- [x] Liste détaillée des présents, absents et peut-être

- [x] Carte réelle interactive dans le module localisation (OpenStreetMap/Leaflet sur web, react-native-maps sur natif)

- [x] Système de rappels automatiques 24h et 1h avant chaque soirée
- [x] Historique Souvenirs dans le profil (groupes terminés, photos, stats)
- [x] Mode Bilan post-soirée (tricount, meilleures photos, partage résumé)
- [x] Correction modification photo profil et bannière événement
- [x] Vérification localisation exacte fonctionne correctement

- [x] Activer synchronisation backend complète pour partage multi-utilisateurs
- [x] Schéma DB complet (groupes, membres, messages, RSVP, tâches, courses)
- [x] Routes API tRPC pour CRUD groupes, membres, messages
- [x] Connexion frontend au backend pour les groupes et RSVP
- [x] Chat synchronisé en temps réel via le backend
- [x] Notifications push entre utilisateurs connectés
- [x] Authentification requise pour la synchronisation

- [x] Système de code d'invitation pour rejoindre une soirée
- [x] Bouton "Rejoindre via code" dans l'écran d'accueil
- [x] Modal de saisie du code d'invitation
- [x] Validation et ajout automatique au groupe

- [x] Corriger la connexion OAuth et l'authentification
- [x] Corriger la modification du profil (photo, nom, username, bio)
- [x] Synchroniser les modifications du profil avec le backend
- [x] Tester la connexion et modification du compte dans Expo Go

- [x] Corriger le code d'invitation pour que les amis puissent rejoindre
- [x] Générer des codes uniques et faciles à partager
- [x] Valider et tester le fonctionnement sur Expo Go

- [x] Corriger l'affichage du code d'invitation dans le Group Hub
- [x] Afficher le code généré automatiquement (ex: PARTY2024)
- [x] Ajouter un bouton copier pour le code
