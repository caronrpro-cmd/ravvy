import { useEffect, useRef } from "react";
import { Platform } from "react-native";
import * as Notifications from "expo-notifications";
import { useApp, generateId } from "@/lib/app-provider";
import { Group } from "@/lib/store";

/**
 * Hook that schedules automatic reminders 24h and 1h before each upcoming event.
 * Uses expo-notifications for push notifications on native,
 * and in-app notifications as fallback on web.
 */
export function useReminders() {
  const { state, dispatch } = useApp();
  const scheduledRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!state.profile) return;

    const now = new Date();
    const upcomingGroups = state.groups.filter((g) => {
      const eventDate = parseEventDate(g);
      return eventDate && eventDate.getTime() > now.getTime();
    });

    upcomingGroups.forEach((group) => {
      const eventDate = parseEventDate(group);
      if (!eventDate) return;

      const diff = eventDate.getTime() - now.getTime();
      const oneHour = 60 * 60 * 1000;
      const twentyFourHours = 24 * 60 * 60 * 1000;

      // Schedule 24h reminder
      const key24h = `${group.id}_24h`;
      if (diff > twentyFourHours && !scheduledRef.current.has(key24h)) {
        scheduledRef.current.add(key24h);
        const delay24h = diff - twentyFourHours;
        scheduleReminder(group, "24h", delay24h, dispatch, generateId);
      }

      // Schedule 1h reminder
      const key1h = `${group.id}_1h`;
      if (diff > oneHour && !scheduledRef.current.has(key1h)) {
        scheduledRef.current.add(key1h);
        const delay1h = diff - oneHour;
        scheduleReminder(group, "1h", delay1h, dispatch, generateId);
      }

      // If event is within 24h but more than 1h away, still schedule 1h
      if (diff <= twentyFourHours && diff > oneHour && !scheduledRef.current.has(key1h)) {
        scheduledRef.current.add(key1h);
        const delay1h = diff - oneHour;
        scheduleReminder(group, "1h", delay1h, dispatch, generateId);
      }
    });
  }, [state.groups, state.profile]);
}

function parseEventDate(group: Group): Date | null {
  try {
    // Try combining date and time
    const dateStr = group.date;
    const timeStr = group.time || "20:00";

    // Handle both ISO and DD/MM/YYYY formats
    let date: Date;
    if (dateStr.includes("T")) {
      date = new Date(dateStr);
    } else if (dateStr.includes("/")) {
      const parts = dateStr.split("/");
      if (parts.length === 3) {
        // DD/MM/YYYY
        date = new Date(`${parts[2]}-${parts[1]}-${parts[0]}T${timeStr}:00`);
      } else {
        date = new Date(dateStr);
      }
    } else {
      date = new Date(`${dateStr}T${timeStr}:00`);
    }

    if (isNaN(date.getTime())) return null;
    return date;
  } catch {
    return null;
  }
}

function scheduleReminder(
  group: Group,
  timing: "24h" | "1h",
  delayMs: number,
  dispatch: any,
  genId: () => string
) {
  const timingLabel = timing === "24h" ? "demain" : "dans 1 heure";
  const title = `Rappel : ${group.name}`;
  const message = `La soirée "${group.name}" commence ${timingLabel} ! Lieu : ${group.location}. N'oubliez pas de vérifier vos tâches et la liste de courses.`;

  // Schedule native push notification on supported platforms
  if (Platform.OS !== "web") {
    scheduleNativeNotification(title, message, delayMs);
  }

  // Also schedule in-app notification via setTimeout
  setTimeout(() => {
    dispatch({
      type: "ADD_NOTIFICATION",
      payload: {
        id: genId(),
        type: "reminder" as const,
        title,
        message,
        groupId: group.id,
        read: false,
        createdAt: new Date().toISOString(),
      },
    });
  }, delayMs);
}

async function scheduleNativeNotification(title: string, body: string, delayMs: number) {
  try {
    const seconds = Math.max(1, Math.floor(delayMs / 1000));
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: true,
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
        seconds,
        repeats: false,
      },
    });
  } catch (e) {
    console.warn("Failed to schedule native notification:", e);
  }
}
