import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useContext } from "react";

// ===== TYPES =====

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  bio: string;
  avatar: string;
  status: "available" | "busy" | "away" | "dnd";
  createdAt: string;
}

export interface Friend {
  id: string;
  name: string;
  username: string;
  avatar: string;
  status: "available" | "busy" | "away" | "dnd";
  addedAt: string;
}

export type GroupType = "classic" | "auto-destruct";

export interface Group {
  id: string;
  name: string;
  description: string;
  type: GroupType;
  coverImage: string;
  date: string;
  time: string;
  location: string;
  createdBy: string;
  createdAt: string;
  expiresAt?: string; // For auto-destruct groups
  invitationCode: string; // Unique code for joining
  members: GroupMember[];
}

export interface GroupMember {
  id: string;
  name: string;
  username: string;
  avatar: string;
  rsvp: "present" | "absent" | "maybe" | "pending";
  role: "admin" | "member";
}

export interface ShoppingItem {
  id: string;
  groupId: string;
  name: string;
  assignedTo?: string;
  status: "to_buy" | "bought";
  price: number;
  addedBy: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  groupId: string;
  description: string;
  amount: number;
  paidBy: string;
  splitBetween: string[];
  createdAt: string;
}

export interface CarpoolRide {
  id: string;
  groupId: string;
  driverId: string;
  driverName: string;
  driverAvatar: string;
  departureLocation: string;
  departureCoords?: { lat: number; lng: number };
  availableSeats: number;
  totalSeats: number;
  passengers: { id: string; name: string; avatar: string }[];
  departureTime: string;
}

export interface ChatMessage {
  id: string;
  groupId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  type: "text" | "image" | "location";
  imageUrl?: string;
  reactions: { emoji: string; userId: string }[];
  isPinned: boolean;
  createdAt: string;
}

export interface PhotoItem {
  id: string;
  groupId: string;
  uri: string;
  uploadedBy: string;
  uploadedByName: string;
  tags: string[];
  createdAt: string;
}

export interface TaskItem {
  id: string;
  groupId: string;
  title: string;
  assignedTo?: string;
  assignedToName?: string;
  priority: "low" | "medium" | "high";
  completed: boolean;
  deadline?: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  type: "rsvp" | "task" | "carpool" | "expense" | "reminder" | "destruct" | "friend" | "chat";
  title: string;
  message: string;
  groupId?: string;
  read: boolean;
  createdAt: string;
}

export interface Poll {
  id: string;
  groupId: string;
  question: string;
  options: PollOption[];
  createdBy: string;
  createdAt: string;
}

export interface PollOption {
  id: string;
  text: string;
  votes: string[]; // user IDs
}

export interface AppState {
  profile: UserProfile | null;
  friends: Friend[];
  friendRequests: Friend[];
  groups: Group[];
  shoppingItems: ShoppingItem[];
  expenses: Expense[];
  carpoolRides: CarpoolRide[];
  chatMessages: ChatMessage[];
  photos: PhotoItem[];
  tasks: TaskItem[];
  notifications: Notification[];
  polls: Poll[];
  onboardingComplete: boolean;
  darkMode: boolean | null; // null = system
}

// ===== STORAGE KEYS =====
const STORAGE_KEY = "@partysync_state";

// ===== DEFAULT STATE =====
export const defaultState: AppState = {
  profile: null,
  friends: [],
  friendRequests: [],
  groups: [],
  shoppingItems: [],
  expenses: [],
  carpoolRides: [],
  chatMessages: [],
  photos: [],
  tasks: [],
  notifications: [],
  polls: [],
  onboardingComplete: false,
  darkMode: null,
};

// ===== PERSISTENCE =====
export async function loadState(): Promise<AppState> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...defaultState, ...JSON.parse(raw) };
    }
  } catch (e) {
    console.warn("Failed to load state:", e);
  }
  return defaultState;
}

export async function saveState(state: AppState): Promise<void> {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("Failed to save state:", e);
  }
}

// ===== HELPERS =====
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
}

export function formatTime(dateStr: string): string {
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
}

export function formatRelativeTime(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return "À l'instant";
  if (minutes < 60) return `Il y a ${minutes}min`;
  if (hours < 24) return `Il y a ${hours}h`;
  if (days < 7) return `Il y a ${days}j`;
  return formatDate(dateStr);
}

export function getTimeRemaining(expiresAt: string): string {
  const now = new Date();
  const expires = new Date(expiresAt);
  const diff = expires.getTime() - now.getTime();

  if (diff <= 0) return "Expiré";

  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);

  if (days > 0) return `${days}j ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}min`;
  return `${minutes}min`;
}
