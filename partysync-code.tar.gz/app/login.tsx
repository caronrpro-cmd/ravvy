import { View, Text, TextInput, Pressable, ScrollView, ActivityIndicator, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useApp } from "@/lib/app-provider";
import { useState } from "react";

export default function LoginScreen() {
  const colors = useColors();
  const router = useRouter();
  const { state, dispatch } = useApp();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);

  // Check if already logged in
  if (state.profile && state.profile.id) {
    router.replace("/(tabs)");
    return null;
  }

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Erreur", "Veuillez remplir tous les champs");
      return;
    }

    setLoading(true);
    try {
      // Simulate login - in production, this would call the backend
      const userId = email.split("@")[0] + "-" + Date.now();
      const newProfile = {
        id: userId,
        name: email.split("@")[0],
        username: email.split("@")[0],
        bio: "",
        avatar: "",
        status: "available" as const,
        createdAt: new Date().toISOString(),
      };

      dispatch({ type: "SET_PROFILE", payload: newProfile });
      Alert.alert("Succès", "Connexion réussie!");
      router.replace("/(tabs)");
    } catch (error) {
      Alert.alert("Erreur", "Connexion échouée");
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    if (!email || !password || !name || !username) {
      Alert.alert("Erreur", "Veuillez remplir tous les champs");
      return;
    }

    if (password.length < 6) {
      Alert.alert("Erreur", "Le mot de passe doit contenir au moins 6 caractères");
      return;
    }

    setLoading(true);
    try {
      // Simulate signup - in production, this would call the backend
      const userId = username + "-" + Date.now();
      const newProfile = {
        id: userId,
        name: name,
        username: username,
        bio: "",
        avatar: "",
        status: "available" as const,
        createdAt: new Date().toISOString(),
      };

      dispatch({ type: "SET_PROFILE", payload: newProfile });
      Alert.alert("Succès", "Compte créé avec succès!");
      router.replace("/(tabs)");
    } catch (error) {
      Alert.alert("Erreur", "Inscription échouée");
    } finally {
      setLoading(false);
    }
  };

  const handleContinueWithoutAccount = () => {
    // Create a temporary guest profile
    const guestProfile = {
      id: "guest-" + Date.now(),
      name: "Utilisateur",
      username: "utilisateur",
      bio: "",
      avatar: "",
      status: "available" as const,
      createdAt: new Date().toISOString(),
    };

    dispatch({ type: "SET_PROFILE", payload: guestProfile });
    router.replace("/(tabs)");
  };

  return (
    <ScreenContainer containerClassName="bg-gradient-to-b from-primary/10 to-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: "center", padding: 24 }}>
        {/* Logo */}
        <View style={{ alignItems: "center", marginBottom: 32 }}>
          <View
            style={{
              width: 80,
              height: 80,
              borderRadius: 20,
              backgroundColor: colors.primary,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 16,
            }}
          >
            <Text style={{ fontSize: 40, fontWeight: "bold", color: colors.background }}>🎉</Text>
          </View>
          <Text style={{ fontSize: 28, fontWeight: "bold", color: colors.foreground, marginBottom: 8 }}>
            PartySync
          </Text>
          <Text style={{ fontSize: 14, color: colors.muted, textAlign: "center" }}>
            Organisez vos soirées avec vos amis
          </Text>
        </View>

        {/* Form */}
        <View style={{ marginBottom: 24 }}>
          {/* Mode Toggle */}
          <View
            style={{
              flexDirection: "row",
              backgroundColor: colors.surface,
              borderRadius: 12,
              padding: 4,
              marginBottom: 24,
            }}
          >
            <Pressable
              onPress={() => setMode("login")}
              style={{
                flex: 1,
                paddingVertical: 12,
                alignItems: "center",
                borderRadius: 10,
                backgroundColor: mode === "login" ? colors.primary : "transparent",
              }}
            >
              <Text
                style={{
                  color: mode === "login" ? colors.background : colors.foreground,
                  fontWeight: "600",
                }}
              >
                Connexion
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setMode("signup")}
              style={{
                flex: 1,
                paddingVertical: 12,
                alignItems: "center",
                borderRadius: 10,
                backgroundColor: mode === "signup" ? colors.primary : "transparent",
              }}
            >
              <Text
                style={{
                  color: mode === "signup" ? colors.background : colors.foreground,
                  fontWeight: "600",
                }}
              >
                Inscription
              </Text>
            </Pressable>
          </View>

          {/* Email Input */}
          <TextInput
            placeholder="Email"
            placeholderTextColor={colors.muted}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
              borderRadius: 12,
              paddingHorizontal: 16,
              paddingVertical: 12,
              marginBottom: 12,
              color: colors.foreground,
              fontSize: 16,
            }}
          />

          {/* Name Input (Signup only) */}
          {mode === "signup" && (
            <TextInput
              placeholder="Nom complet"
              placeholderTextColor={colors.muted}
              value={name}
              onChangeText={setName}
              style={{
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderWidth: 1,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 12,
                marginBottom: 12,
                color: colors.foreground,
                fontSize: 16,
              }}
            />
          )}

          {/* Username Input (Signup only) */}
          {mode === "signup" && (
            <TextInput
              placeholder="Nom d'utilisateur"
              placeholderTextColor={colors.muted}
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              style={{
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderWidth: 1,
                borderRadius: 12,
                paddingHorizontal: 16,
                paddingVertical: 12,
                marginBottom: 12,
                color: colors.foreground,
                fontSize: 16,
              }}
            />
          )}

          {/* Password Input */}
          <TextInput
            placeholder="Mot de passe"
            placeholderTextColor={colors.muted}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
              borderRadius: 12,
              paddingHorizontal: 16,
              paddingVertical: 12,
              marginBottom: 24,
              color: colors.foreground,
              fontSize: 16,
            }}
          />

          {/* Submit Button */}
          <Pressable
            onPress={mode === "login" ? handleLogin : handleSignup}
            disabled={loading}
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            {loading ? (
              <ActivityIndicator color={colors.background} />
            ) : (
              <Text style={{ color: colors.background, fontWeight: "700", fontSize: 16 }}>
                {mode === "login" ? "Se connecter" : "Créer un compte"}
              </Text>
            )}
          </Pressable>
        </View>

        {/* Divider */}
        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 24 }}>
          <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
          <Text style={{ color: colors.muted, marginHorizontal: 12, fontSize: 14 }}>ou</Text>
          <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
        </View>

        {/* Continue without account */}
        <Pressable
          onPress={handleContinueWithoutAccount}
          style={({ pressed }) => [
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 16 }}>
            Continuer sans compte
          </Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}
