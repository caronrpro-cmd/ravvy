import { useState } from "react";
import { Text, View, Pressable, TextInput, Modal, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useApp } from "@/lib/app-provider";
import { useEffect } from "react";

export default function JoinByCodeScreen() {
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const { state, dispatch } = useApp();
  const colors = useColors();
  const router = useRouter();

  const handleJoinGroup = async () => {
    if (!code.trim()) {
      Alert.alert("Erreur", "Veuillez entrer un code d'invitation");
      return;
    }

    setLoading(true);

    // Simulate API call to validate and join group
    setTimeout(() => {
      // Find group by invitation code
      const groupToJoin = state.groups.find(
        (g) => g.invitationCode.toUpperCase() === code.toUpperCase()
      );

      if (!groupToJoin) {
        Alert.alert("Erreur", "Code d'invitation invalide ou expiré");
        setLoading(false);
        return;
      }

      // Check if already a member
      if (groupToJoin.members.some((m) => m.id === state.profile?.id)) {
        Alert.alert("Info", "Vous êtes déjà membre de ce groupe");
        setLoading(false);
        return;
      }

      // Add current user to group
      const newMember = {
        id: state.profile?.id || "user-" + Date.now(),
        name: state.profile?.name || "Utilisateur",
        username: state.profile?.username || "user",
        avatar: state.profile?.avatar || "",
        rsvp: "maybe" as const,
        role: "member" as const,
      };

      const updatedMembers = [...groupToJoin.members, newMember];
      dispatch({ type: "UPDATE_GROUP", payload: { id: groupToJoin.id, updates: { members: updatedMembers } } });

      Alert.alert("Succès!", `Vous avez rejoint "${groupToJoin.name}"`, [
        {
          text: "Voir le groupe",
          onPress: () => {
            router.push(`/group/${groupToJoin.id}` as any);
          },
        },
        {
          text: "Retour",
          onPress: () => router.back(),
        },
      ]);

      setLoading(false);
    }, 500);
  };

  return (
    <ScreenContainer className="p-6">
      <View className="flex-1">
        {/* Header */}
        <View className="flex-row items-center mb-6">
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [
              {
                width: 44,
                height: 44,
                borderRadius: 22,
                backgroundColor: colors.surface,
                alignItems: "center",
                justifyContent: "center",
              },
              pressed && { opacity: 0.7 },
            ]}
          >
            <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
          </Pressable>
          <Text className="text-foreground text-2xl font-bold flex-1 ml-4">
            Rejoindre une soirée
          </Text>
        </View>

        {/* Info Section */}
        <View className="bg-surface rounded-2xl p-4 mb-6 border border-border">
          <View className="flex-row gap-3">
            <IconSymbol name="info.circle.fill" size={20} color={colors.primary} />
            <Text className="text-foreground text-sm flex-1">
              Entrez le code d'invitation fourni par l'organisateur de la soirée pour la rejoindre.
            </Text>
          </View>
        </View>

        {/* Code Input */}
        <View className="mb-6">
          <Text className="text-foreground font-semibold mb-2">Code d'invitation</Text>
          <TextInput
            placeholder="Ex: PARTY2024"
            placeholderTextColor={colors.muted}
            value={code}
            onChangeText={setCode}
            editable={!loading}
            autoCapitalize="characters"
            maxLength={12}
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderWidth: 1,
              borderRadius: 12,
              paddingHorizontal: 16,
              paddingVertical: 12,
              fontSize: 16,
              color: colors.foreground,
              fontWeight: "600",
              letterSpacing: 2,
            }}
          />
          <Text className="text-muted text-xs mt-2">
            {code.length}/12 caractères
          </Text>
        </View>

        {/* Join Button */}
        <Pressable
          onPress={handleJoinGroup}
          disabled={loading || !code.trim()}
          style={({ pressed }) => [
            {
              backgroundColor: code.trim() ? colors.primary : colors.muted,
              borderRadius: 12,
              paddingVertical: 14,
              alignItems: "center",
              opacity: loading ? 0.7 : 1,
            },
            pressed && code.trim() && { transform: [{ scale: 0.97 }] },
          ]}
        >
          <Text
            style={{
              color: "#FFF",
              fontWeight: "600",
              fontSize: 16,
            }}
          >
            {loading ? "Vérification..." : "Rejoindre"}
          </Text>
        </Pressable>

        {/* Example Section */}
        <View className="mt-8 pt-6 border-t border-border">
          <Text className="text-muted text-sm font-semibold mb-3">Exemple d'utilisation :</Text>
          <View className="bg-surface rounded-xl p-4 gap-2">
            <Text className="text-foreground text-sm">
              1. L'organisateur partage un code (ex: <Text className="font-mono">PARTY2024</Text>)
            </Text>
            <Text className="text-foreground text-sm">
              2. Vous entrez le code ci-dessus
            </Text>
            <Text className="text-foreground text-sm">
              3. Vous êtes automatiquement ajouté au groupe
            </Text>
          </View>
        </View>
      </View>
    </ScreenContainer>
  );
}
