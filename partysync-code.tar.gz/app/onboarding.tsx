import { useState, useRef } from "react";
import { Text, View, Pressable, Dimensions, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useApp } from "@/lib/app-provider";

const { width } = Dimensions.get("window");

const slides = [
  {
    emoji: "🎉",
    title: "Organisez vos soirées",
    subtitle: "Créez des groupes, invitez vos amis et planifiez vos événements en quelques taps.",
    color: "#7C3AED",
  },
  {
    emoji: "🤝",
    title: "Collaborez en temps réel",
    subtitle: "Courses, covoiturage, tâches, chat... Tout est partagé et synchronisé entre amis.",
    color: "#F59E0B",
  },
  {
    emoji: "🛡️",
    title: "Rentrez en sécurité",
    subtitle: "Partagez votre position, utilisez le bouton SOS et gardez un œil sur vos amis.",
    color: "#10B981",
  },
];

export default function OnboardingScreen() {
  const colors = useColors();
  const router = useRouter();
  const { dispatch } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({ index: currentIndex + 1 });
      setCurrentIndex(currentIndex + 1);
    } else {
      dispatch({ type: "COMPLETE_ONBOARDING" });
      router.replace("/(tabs)" as any);
    }
  };

  const handleSkip = () => {
    dispatch({ type: "COMPLETE_ONBOARDING" });
    router.replace("/(tabs)" as any);
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <View style={{ flex: 1 }}>
        {/* Skip button */}
        <View style={{ alignItems: "flex-end", paddingHorizontal: 20, paddingTop: 10 }}>
          <Pressable
            onPress={handleSkip}
            style={({ pressed }) => [pressed && { opacity: 0.7 }]}
          >
            <Text style={{ color: colors.muted, fontSize: 15, fontWeight: "500" }}>Passer</Text>
          </Pressable>
        </View>

        {/* Slides */}
        <FlatList
          ref={flatListRef}
          data={slides}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          scrollEnabled={false}
          keyExtractor={(_, i) => i.toString()}
          renderItem={({ item }) => (
            <View
              style={{
                width,
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
                paddingHorizontal: 40,
              }}
            >
              <View
                style={{
                  width: 120,
                  height: 120,
                  borderRadius: 30,
                  backgroundColor: item.color + "15",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 30,
                }}
              >
                <Text style={{ fontSize: 56 }}>{item.emoji}</Text>
              </View>
              <Text
                style={{
                  fontSize: 28,
                  fontWeight: "800",
                  color: colors.foreground,
                  textAlign: "center",
                  marginBottom: 12,
                }}
              >
                {item.title}
              </Text>
              <Text
                style={{
                  fontSize: 16,
                  color: colors.muted,
                  textAlign: "center",
                  lineHeight: 24,
                }}
              >
                {item.subtitle}
              </Text>
            </View>
          )}
        />

        {/* Dots & Button */}
        <View style={{ paddingHorizontal: 20, paddingBottom: 30 }}>
          {/* Dots */}
          <View
            style={{
              flexDirection: "row",
              justifyContent: "center",
              gap: 8,
              marginBottom: 24,
            }}
          >
            {slides.map((_, i) => (
              <View
                key={i}
                style={{
                  width: currentIndex === i ? 24 : 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: currentIndex === i ? colors.primary : colors.border,
                }}
              />
            ))}
          </View>

          {/* Button */}
          <Pressable
            onPress={handleNext}
            style={({ pressed }) => [
              {
                backgroundColor: slides[currentIndex].color,
                borderRadius: 16,
                padding: 18,
                alignItems: "center",
              },
              pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
            ]}
          >
            <Text style={{ color: "#FFF", fontWeight: "700", fontSize: 17 }}>
              {currentIndex === slides.length - 1 ? "Commencer" : "Suivant"}
            </Text>
          </Pressable>
        </View>
      </View>
    </ScreenContainer>
  );
}
