import { useState } from "react";
import { Text, View, Pressable, ScrollView, TextInput, Alert, Platform } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useApp, generateId } from "@/lib/app-provider";

export default function CarpoolScreen() {
  const { state, dispatch } = useApp();
  const colors = useColors();
  const router = useRouter();
  const { groupId } = useLocalSearchParams<{ groupId: string }>();

  const [showAdd, setShowAdd] = useState(false);
  const [departure, setDeparture] = useState("");
  const [seats, setSeats] = useState("3");
  const [departureTime, setDepartureTime] = useState("");

  const rides = state.carpoolRides.filter((r) => r.groupId === groupId);
  const userId = state.profile?.id || "user_1";

  // Check if user is already in a ride (as passenger)
  const myCurrentRide = rides.find((r) => r.passengers.some((p) => p.id === userId));
  // Check if user is a driver
  const myDriverRide = rides.find((r) => r.driverId === userId);

  const handleAddRide = () => {
    if (!departure.trim()) return;
    dispatch({
      type: "ADD_CARPOOL_RIDE",
      payload: {
        id: generateId(),
        groupId: groupId!,
        driverId: userId,
        driverName: state.profile?.name || "Moi",
        driverAvatar: "",
        departureLocation: departure.trim(),
        availableSeats: parseInt(seats) || 3,
        totalSeats: parseInt(seats) || 3,
        passengers: [],
        departureTime: departureTime || new Date().toISOString(),
      },
    });
    setDeparture("");
    setSeats("3");
    setDepartureTime("");
    setShowAdd(false);
  };

  const handleJoin = (rideId: string) => {
    const ride = rides.find((r) => r.id === rideId);
    if (!ride) return;

    const imPassenger = ride.passengers.some((p) => p.id === userId);

    if (imPassenger) {
      // Leave this ride
      dispatch({ type: "LEAVE_CARPOOL", payload: { rideId, passengerId: userId } });
      return;
    }

    // Check if already in another ride
    if (myCurrentRide) {
      const doSwitch = () => {
        // Leave current ride first
        dispatch({ type: "LEAVE_CARPOOL", payload: { rideId: myCurrentRide.id, passengerId: userId } });
        // Join new ride
        if (ride.availableSeats > 0) {
          dispatch({
            type: "JOIN_CARPOOL",
            payload: {
              rideId,
              passenger: { id: userId, name: state.profile?.name || "Moi", avatar: "" },
            },
          });
        }
      };

      if (Platform.OS === "web") {
        if (confirm(`Vous êtes déjà dans la voiture de ${myCurrentRide.driverName}. Voulez-vous changer ?`)) {
          doSwitch();
        }
      } else {
        Alert.alert(
          "Changer de voiture",
          `Vous êtes déjà dans la voiture de ${myCurrentRide.driverName}. Voulez-vous changer ?`,
          [
            { text: "Non", style: "cancel" },
            { text: "Changer", onPress: doSwitch },
          ]
        );
      }
      return;
    }

    // Join ride
    if (ride.availableSeats <= 0) {
      if (Platform.OS === "web") alert("Plus de places disponibles !");
      else Alert.alert("Complet", "Plus de places disponibles dans cette voiture.");
      return;
    }

    dispatch({
      type: "JOIN_CARPOOL",
      payload: {
        rideId,
        passenger: { id: userId, name: state.profile?.name || "Moi", avatar: "" },
      },
    });
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View className="flex-row items-center justify-between px-5 pt-2 pb-3">
        <View className="flex-row items-center gap-3">
          <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
            <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
          </Pressable>
          <Text className="text-foreground text-xl font-bold">Covoiturage</Text>
        </View>
        <Pressable
          onPress={() => setShowAdd(!showAdd)}
          style={({ pressed }) => [
            { backgroundColor: colors.primary, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10 },
            pressed && { opacity: 0.7 },
          ]}
        >
          <Text style={{ color: "#FFF", fontWeight: "600", fontSize: 13 }}>Je conduis</Text>
        </Pressable>
      </View>

      {/* Current ride info banner */}
      {myCurrentRide && (
        <View className="px-5 mb-3">
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              padding: 12,
              borderRadius: 12,
              backgroundColor: colors.primary + "10",
              borderWidth: 1,
              borderColor: colors.primary + "30",
              gap: 8,
            }}
          >
            <IconSymbol name="car.fill" size={16} color={colors.primary} />
            <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "600", flex: 1 }}>
              Vous êtes dans la voiture de {myCurrentRide.driverName}
            </Text>
            <Pressable
              onPress={() => dispatch({ type: "LEAVE_CARPOOL", payload: { rideId: myCurrentRide.id, passengerId: userId } })}
              style={({ pressed }) => [
                {
                  backgroundColor: colors.error + "15",
                  paddingHorizontal: 10,
                  paddingVertical: 4,
                  borderRadius: 8,
                },
                pressed && { opacity: 0.7 },
              ]}
            >
              <Text style={{ color: colors.error, fontSize: 11, fontWeight: "600" }}>Quitter</Text>
            </Pressable>
          </View>
        </View>
      )}

      {/* Summary */}
      <View className="px-5 mb-4">
        <View style={{ flexDirection: "row", gap: 10 }}>
          <View style={{ flex: 1, backgroundColor: "#3B82F6" + "15", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: "#3B82F6" + "30", alignItems: "center" }}>
            <IconSymbol name="car.fill" size={24} color="#3B82F6" />
            <Text className="text-foreground text-xl font-bold mt-1">{rides.length}</Text>
            <Text className="text-muted text-xs">Voitures</Text>
          </View>
          <View style={{ flex: 1, backgroundColor: colors.success + "15", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.success + "30", alignItems: "center" }}>
            <IconSymbol name="person.2.fill" size={24} color={colors.success} />
            <Text className="text-foreground text-xl font-bold mt-1">
              {rides.reduce((sum, r) => sum + r.availableSeats, 0)}
            </Text>
            <Text className="text-muted text-xs">Places dispo</Text>
          </View>
        </View>
      </View>

      {/* Add Ride Form */}
      {showAdd && (
        <View className="px-5 mb-4">
          <View style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.primary }}>
            <Text className="text-foreground font-semibold mb-2">Proposer un trajet</Text>
            <TextInput
              placeholder="Lieu de départ"
              placeholderTextColor={colors.muted}
              value={departure}
              onChangeText={setDeparture}
              style={{ backgroundColor: colors.background, borderRadius: 10, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border, marginBottom: 8 }}
            />
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 10 }}>
              <View style={{ flex: 1 }}>
                <Text className="text-muted text-xs mb-1">Places</Text>
                <TextInput
                  placeholder="3"
                  placeholderTextColor={colors.muted}
                  value={seats}
                  onChangeText={setSeats}
                  keyboardType="numeric"
                  style={{ backgroundColor: colors.background, borderRadius: 10, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border, textAlign: "center" }}
                />
              </View>
              <View style={{ flex: 2 }}>
                <Text className="text-muted text-xs mb-1">Heure de départ</Text>
                <TextInput
                  placeholder="HH:MM"
                  placeholderTextColor={colors.muted}
                  value={departureTime}
                  onChangeText={setDepartureTime}
                  style={{ backgroundColor: colors.background, borderRadius: 10, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border }}
                />
              </View>
            </View>
            <Pressable
              onPress={handleAddRide}
              style={({ pressed }) => [
                { backgroundColor: colors.primary, borderRadius: 10, padding: 12, alignItems: "center" },
                pressed && { opacity: 0.7 },
              ]}
            >
              <Text style={{ color: "#FFF", fontWeight: "600" }}>Proposer le trajet</Text>
            </Pressable>
          </View>
        </View>
      )}

      {/* Rides List */}
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
        {rides.length === 0 ? (
          <View className="items-center py-12">
            <IconSymbol name="car.fill" size={48} color={colors.muted} />
            <Text className="text-muted mt-3 text-center">
              Aucun trajet proposé.{"\n"}Soyez le premier à conduire !
            </Text>
          </View>
        ) : (
          rides.map((ride) => {
            const isMyRide = ride.driverId === userId;
            const imPassenger = ride.passengers.some((p) => p.id === userId);
            const isInAnotherRide = myCurrentRide && myCurrentRide.id !== ride.id;
            return (
              <View
                key={ride.id}
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 16,
                  padding: 16,
                  marginBottom: 10,
                  borderWidth: imPassenger ? 2 : 1,
                  borderColor: imPassenger ? colors.primary : colors.border,
                }}
              >
                {/* Driver */}
                <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
                  <View
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 22,
                      backgroundColor: "#3B82F6" + "25",
                      alignItems: "center",
                      justifyContent: "center",
                      marginRight: 12,
                    }}
                  >
                    <IconSymbol name="car.fill" size={20} color="#3B82F6" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                      <Text className="text-foreground font-bold text-sm">{ride.driverName}</Text>
                      <View style={{ backgroundColor: "#3B82F6" + "20", paddingHorizontal: 6, paddingVertical: 1, borderRadius: 4 }}>
                        <Text style={{ color: "#3B82F6", fontSize: 9, fontWeight: "700" }}>CONDUCTEUR</Text>
                      </View>
                    </View>
                    <Text className="text-muted text-xs mt-1">📍 {ride.departureLocation}</Text>
                  </View>
                </View>

                {/* Seats visual */}
                <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12, gap: 4 }}>
                  {Array.from({ length: ride.totalSeats }).map((_, i) => {
                    const occupied = i < ride.totalSeats - ride.availableSeats;
                    const passengerName = occupied && ride.passengers[i] ? ride.passengers[i].name : null;
                    return (
                      <View key={i} style={{ alignItems: "center" }}>
                        <View
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: 14,
                            backgroundColor: occupied ? colors.primary + "25" : colors.border + "50",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          <IconSymbol
                            name="person.fill"
                            size={14}
                            color={occupied ? colors.primary : colors.muted}
                          />
                        </View>
                        {passengerName && (
                          <Text style={{ color: colors.muted, fontSize: 8, marginTop: 2 }} numberOfLines={1}>
                            {passengerName.split(" ")[0]}
                          </Text>
                        )}
                      </View>
                    );
                  })}
                  <Text className="text-muted text-xs ml-2">
                    {ride.availableSeats} place{ride.availableSeats !== 1 ? "s" : ""} dispo
                  </Text>
                </View>

                {/* Passengers list */}
                {ride.passengers.length > 0 && (
                  <View style={{ marginBottom: 12 }}>
                    <Text className="text-muted text-xs mb-2">Passagers :</Text>
                    <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                      {ride.passengers.map((p) => (
                        <View
                          key={p.id}
                          style={{
                            backgroundColor: p.id === userId ? colors.primary + "25" : colors.primary + "10",
                            paddingHorizontal: 10,
                            paddingVertical: 4,
                            borderRadius: 8,
                            borderWidth: p.id === userId ? 1 : 0,
                            borderColor: colors.primary,
                          }}
                        >
                          <Text style={{ color: colors.primary, fontSize: 12, fontWeight: "600" }}>
                            {p.name} {p.id === userId ? "(vous)" : ""}
                          </Text>
                        </View>
                      ))}
                    </View>
                  </View>
                )}

                {/* Action */}
                {!isMyRide && (
                  <Pressable
                    onPress={() => handleJoin(ride.id)}
                    style={({ pressed }) => [
                      {
                        backgroundColor: imPassenger ? colors.error + "15" : isInAnotherRide ? colors.warning + "15" : colors.primary,
                        borderRadius: 10,
                        padding: 12,
                        alignItems: "center",
                        borderWidth: imPassenger || isInAnotherRide ? 1 : 0,
                        borderColor: imPassenger ? colors.error : colors.warning,
                        flexDirection: "row",
                        justifyContent: "center",
                        gap: 6,
                      },
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    {imPassenger ? (
                      <>
                        <IconSymbol name="xmark.circle.fill" size={16} color={colors.error} />
                        <Text style={{ color: colors.error, fontWeight: "600", fontSize: 14 }}>
                          Me retirer
                        </Text>
                      </>
                    ) : isInAnotherRide ? (
                      <>
                        <IconSymbol name="arrow.right.arrow.left" size={16} color={colors.warning} />
                        <Text style={{ color: colors.warning, fontWeight: "600", fontSize: 14 }}>
                          Changer de voiture
                        </Text>
                      </>
                    ) : (
                      <Text style={{ color: "#FFF", fontWeight: "600", fontSize: 14 }}>
                        Réserver une place
                      </Text>
                    )}
                  </Pressable>
                )}
                {isMyRide && (
                  <Pressable
                    onPress={() => dispatch({ type: "DELETE_CARPOOL_RIDE", payload: ride.id })}
                    style={({ pressed }) => [
                      {
                        backgroundColor: colors.error + "15",
                        borderRadius: 10,
                        padding: 12,
                        alignItems: "center",
                        borderWidth: 1,
                        borderColor: colors.error,
                      },
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    <Text style={{ color: colors.error, fontWeight: "600", fontSize: 14 }}>Supprimer mon trajet</Text>
                  </Pressable>
                )}
              </View>
            );
          })
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
