import { useState } from "react";
import { Text, View, Pressable, ScrollView, Dimensions, Platform, Alert } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useApp, generateId } from "@/lib/app-provider";
import { formatDate } from "@/lib/store";

const { width } = Dimensions.get("window");
const PHOTO_SIZE = (width - 48) / 3;

export default function AlbumScreen() {
  const { state, dispatch } = useApp();
  const colors = useColors();
  const router = useRouter();
  const { groupId } = useLocalSearchParams<{ groupId: string }>();

  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  const photos = state.photos.filter((p) => p.groupId === groupId);

  const handlePickFromLibrary = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true,
        quality: 0.8,
      });

      if (!result.canceled && result.assets.length > 0) {
        result.assets.forEach((asset) => {
          dispatch({
            type: "ADD_PHOTO",
            payload: {
              id: generateId(),
              groupId: groupId!,
              uri: asset.uri,
              uploadedBy: state.profile?.id || "user_1",
              uploadedByName: state.profile?.name || "Moi",
              tags: [],
              createdAt: new Date().toISOString(),
            },
          });
        });
      }
    } catch (e) {
      console.warn("ImagePicker error:", e);
    }
  };

  const handleTakePhoto = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== "granted") {
        const msg = "Permission caméra nécessaire pour prendre une photo";
        if (Platform.OS === "web") alert(msg);
        else Alert.alert("Permission refusée", msg);
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        dispatch({
          type: "ADD_PHOTO",
          payload: {
            id: generateId(),
            groupId: groupId!,
            uri: result.assets[0].uri,
            uploadedBy: state.profile?.id || "user_1",
            uploadedByName: state.profile?.name || "Moi",
            tags: [],
            createdAt: new Date().toISOString(),
          },
        });
      }
    } catch (e) {
      console.warn("Camera error:", e);
    }
  };

  const [showAddMenu, setShowAddMenu] = useState(false);
  const selectedPhotoData = photos.find((p) => p.id === selectedPhoto);

  const isRealImage = (uri: string) => !uri.startsWith("#");

  return (
    <ScreenContainer>
      {/* Header */}
      <View className="flex-row items-center justify-between px-5 pt-2 pb-3">
        <View className="flex-row items-center gap-3">
          <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
            <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
          </Pressable>
          <Text className="text-foreground text-xl font-bold">Album Photo</Text>
        </View>
        <Pressable
          onPress={() => setShowAddMenu(!showAddMenu)}
          style={({ pressed }) => [
            { backgroundColor: colors.primary, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 4 },
            pressed && { opacity: 0.7 },
          ]}
        >
          <IconSymbol name="plus" size={14} color="#FFF" />
          <Text style={{ color: "#FFF", fontWeight: "600", fontSize: 13 }}>Ajouter</Text>
        </Pressable>
      </View>

      {/* Add Menu */}
      {showAddMenu && (
        <View className="px-5 mb-3">
          <View style={{ flexDirection: "row", gap: 8 }}>
            <Pressable
              onPress={() => { setShowAddMenu(false); handlePickFromLibrary(); }}
              style={({ pressed }) => [
                {
                  flex: 1,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  padding: 12,
                  borderRadius: 12,
                  backgroundColor: colors.primary + "15",
                  borderWidth: 1,
                  borderColor: colors.primary + "30",
                },
                pressed && { opacity: 0.7 },
              ]}
            >
              <IconSymbol name="photo.fill" size={16} color={colors.primary} />
              <Text style={{ color: colors.primary, fontWeight: "600", fontSize: 13 }}>Galerie</Text>
            </Pressable>
            <Pressable
              onPress={() => { setShowAddMenu(false); handleTakePhoto(); }}
              style={({ pressed }) => [
                {
                  flex: 1,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  padding: 12,
                  borderRadius: 12,
                  backgroundColor: "#F59E0B" + "15",
                  borderWidth: 1,
                  borderColor: "#F59E0B" + "30",
                },
                pressed && { opacity: 0.7 },
              ]}
            >
              <IconSymbol name="camera.fill" size={16} color="#F59E0B" />
              <Text style={{ color: "#F59E0B", fontWeight: "600", fontSize: 13 }}>Caméra</Text>
            </Pressable>
          </View>
        </View>
      )}

      {/* Stats */}
      <View className="px-5 mb-4">
        <View style={{ flexDirection: "row", gap: 10 }}>
          <View style={{ flex: 1, backgroundColor: "#EC4899" + "15", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: "#EC4899" + "30", alignItems: "center" }}>
            <Text className="text-foreground text-xl font-bold">{photos.length}</Text>
            <Text className="text-muted text-xs">Photos</Text>
          </View>
          <View style={{ flex: 1, backgroundColor: colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center" }}>
            <Text className="text-foreground text-xl font-bold">
              {new Set(photos.map((p) => p.uploadedBy)).size}
            </Text>
            <Text className="text-muted text-xs">Contributeurs</Text>
          </View>
        </View>
      </View>

      {/* Photo Grid */}
      <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
        {photos.length === 0 ? (
          <View className="items-center py-12">
            <IconSymbol name="photo.fill" size={48} color={colors.muted} />
            <Text className="text-muted mt-3 text-center">
              Aucune photo pour le moment.{"\n"}Ajoutez des souvenirs !
            </Text>
          </View>
        ) : (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 4 }}>
            {photos.map((photo) => (
              <Pressable
                key={photo.id}
                onPress={() => setSelectedPhoto(photo.id)}
                style={({ pressed }) => [
                  {
                    width: PHOTO_SIZE,
                    height: PHOTO_SIZE,
                    borderRadius: 10,
                    backgroundColor: isRealImage(photo.uri) ? colors.surface : photo.uri,
                    alignItems: "center",
                    justifyContent: "center",
                    overflow: "hidden",
                  },
                  pressed && { opacity: 0.8 },
                ]}
              >
                {isRealImage(photo.uri) ? (
                  <Image
                    source={{ uri: photo.uri }}
                    style={{ width: PHOTO_SIZE, height: PHOTO_SIZE }}
                    contentFit="cover"
                  />
                ) : (
                  <>
                    <IconSymbol name="photo.fill" size={24} color="#FFFFFF80" />
                    <Text style={{ color: "#FFFFFF80", fontSize: 10, marginTop: 4 }}>
                      {photo.uploadedByName}
                    </Text>
                  </>
                )}
              </Pressable>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Photo Detail Modal */}
      {selectedPhotoData && (
        <Pressable
          onPress={() => setSelectedPhoto(null)}
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "rgba(0,0,0,0.9)",
            justifyContent: "center",
            alignItems: "center",
            padding: 20,
          }}
        >
          {isRealImage(selectedPhotoData.uri) ? (
            <Image
              source={{ uri: selectedPhotoData.uri }}
              style={{
                width: width - 40,
                height: width - 40,
                borderRadius: 16,
                marginBottom: 16,
              }}
              contentFit="contain"
            />
          ) : (
            <View
              style={{
                width: width - 40,
                height: width - 40,
                borderRadius: 16,
                backgroundColor: selectedPhotoData.uri,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 16,
              }}
            >
              <IconSymbol name="photo.fill" size={48} color="#FFFFFF80" />
            </View>
          )}
          <Text style={{ color: "#FFF", fontWeight: "600", fontSize: 16 }}>
            Par {selectedPhotoData.uploadedByName}
          </Text>
          <Text style={{ color: "#FFFFFF80", fontSize: 13, marginTop: 4 }}>
            {formatDate(selectedPhotoData.createdAt)}
          </Text>
          <View style={{ flexDirection: "row", gap: 12, marginTop: 16 }}>
            <Pressable
              onPress={() => {
                dispatch({ type: "DELETE_PHOTO", payload: selectedPhotoData.id });
                setSelectedPhoto(null);
              }}
              style={({ pressed }) => [
                { backgroundColor: "#EF444430", paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 },
                pressed && { opacity: 0.7 },
              ]}
            >
              <Text style={{ color: "#EF4444", fontWeight: "600" }}>Supprimer</Text>
            </Pressable>
            <Pressable
              onPress={() => setSelectedPhoto(null)}
              style={({ pressed }) => [
                { backgroundColor: "#FFFFFF20", paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 },
                pressed && { opacity: 0.7 },
              ]}
            >
              <Text style={{ color: "#FFF", fontWeight: "600" }}>Fermer</Text>
            </Pressable>
          </View>
        </Pressable>
      )}
    </ScreenContainer>
  );
}
