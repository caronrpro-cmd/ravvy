import { useState, useRef, useEffect } from "react";
import { Text, View, Pressable, TextInput, FlatList, KeyboardAvoidingView, Platform } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useApp, generateId } from "@/lib/app-provider";

export default function ChatScreen() {
  const { state, dispatch } = useApp();
  const colors = useColors();
  const router = useRouter();
  const { groupId } = useLocalSearchParams<{ groupId: string }>();
  const [message, setMessage] = useState("");
  const flatListRef = useRef<FlatList>(null);

  const group = state.groups.find((g) => g.id === groupId);
  const messages = state.chatMessages.filter((m) => m.groupId === groupId);
  const myId = state.profile?.id || "user_1";

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: false }), 100);
    }
  }, [messages.length]);

  const handleSend = () => {
    if (!message.trim()) return;
    dispatch({
      type: "ADD_MESSAGE",
      payload: {
        id: generateId(),
        groupId: groupId!,
        senderId: myId,
        senderName: state.profile?.name || "Moi",
        senderAvatar: "",
        text: message.trim(),
        type: "text",
        reactions: [],
        isPinned: false,
        createdAt: new Date().toISOString(),
      },
    });
    setMessage("");
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const formatMsgTime = (ts: string) => {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={0}
      >
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 20,
            paddingVertical: 10,
            borderBottomWidth: 0.5,
            borderBottomColor: colors.border,
          }}
        >
          <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
            <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
          </Pressable>
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text className="text-foreground font-bold text-base" numberOfLines={1}>
              {group?.name || "Chat"}
            </Text>
            <Text className="text-muted text-xs">{group?.members.length || 0} participants</Text>
          </View>
        </View>

        {/* Messages */}
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16, paddingBottom: 8 }}
          ListEmptyComponent={
            <View style={{ alignItems: "center", paddingVertical: 60 }}>
              <IconSymbol name="bubble.left.fill" size={48} color={colors.muted} />
              <Text className="text-muted mt-3 text-center">
                Aucun message.{"\n"}Commencez la conversation !
              </Text>
            </View>
          }
          renderItem={({ item: msg, index }) => {
            const isMe = msg.senderId === myId;
            const showAvatar = !isMe && (index === 0 || messages[index - 1]?.senderId !== msg.senderId);

            return (
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: isMe ? "flex-end" : "flex-start",
                  marginBottom: 4,
                  marginTop: showAvatar ? 8 : 0,
                }}
              >
                {!isMe && (
                  <View style={{ width: 30, marginRight: 6 }}>
                    {showAvatar && (
                      <View
                        style={{
                          width: 28,
                          height: 28,
                          borderRadius: 14,
                          backgroundColor: colors.primary + "25",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <Text style={{ fontWeight: "700", color: colors.primary, fontSize: 11 }}>
                          {msg.senderName.charAt(0)}
                        </Text>
                      </View>
                    )}
                  </View>
                )}
                <View style={{ maxWidth: "75%" }}>
                  {showAvatar && !isMe && (
                    <Text style={{ color: colors.muted, fontSize: 11, fontWeight: "600", marginBottom: 2, marginLeft: 4 }}>
                      {msg.senderName}
                    </Text>
                  )}
                  <View
                    style={{
                      backgroundColor: isMe ? colors.primary : colors.surface,
                      borderRadius: 16,
                      borderTopLeftRadius: isMe ? 16 : 4,
                      borderTopRightRadius: isMe ? 4 : 16,
                      paddingHorizontal: 14,
                      paddingVertical: 10,
                    }}
                  >
                    <Text
                      style={{
                        color: isMe ? "#FFF" : colors.foreground,
                        fontSize: 14,
                        lineHeight: 20,
                      }}
                    >
                      {msg.text}
                    </Text>
                    <Text
                      style={{
                        color: isMe ? "#FFFFFF80" : colors.muted,
                        fontSize: 10,
                        textAlign: "right",
                        marginTop: 4,
                      }}
                    >
                      {formatMsgTime(msg.createdAt)}
                    </Text>
                  </View>
                </View>
              </View>
            );
          }}
        />

        {/* Input */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "flex-end",
            paddingHorizontal: 12,
            paddingVertical: 8,
            paddingBottom: Platform.OS === "web" ? 12 : 30,
            borderTopWidth: 0.5,
            borderTopColor: colors.border,
            backgroundColor: colors.background,
            gap: 8,
          }}
        >
          <TextInput
            placeholder="Message..."
            placeholderTextColor={colors.muted}
            value={message}
            onChangeText={setMessage}
            multiline
            returnKeyType="send"
            onSubmitEditing={handleSend}
            style={{
              flex: 1,
              backgroundColor: colors.surface,
              borderRadius: 20,
              paddingHorizontal: 16,
              paddingVertical: 10,
              color: colors.foreground,
              fontSize: 15,
              maxHeight: 100,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          />
          <Pressable
            onPress={handleSend}
            style={({ pressed }) => [
              {
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: message.trim() ? colors.primary : colors.surface,
                alignItems: "center",
                justifyContent: "center",
              },
              pressed && { opacity: 0.7, transform: [{ scale: 0.95 }] },
            ]}
          >
            <IconSymbol name="paperplane.fill" size={18} color={message.trim() ? "#FFF" : colors.muted} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}
