import { useState } from "react";
import { Text, View, Pressable, ScrollView, Alert, Platform } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useApp, generateId } from "@/lib/app-provider";
import { formatDate, getTimeRemaining } from "@/lib/store";

const RSVP_CONFIG = {
  present: { label: "Présent", color: "#10B981", emoji: "✅" },
  absent: { label: "Absent", color: "#EF4444", emoji: "❌" },
  maybe: { label: "Peut-être", color: "#F59E0B", emoji: "🤔" },
  pending: { label: "En attente", color: "#6B7280", emoji: "⏳" },
};

export default function GroupHubScreen() {
  const { state, dispatch } = useApp();
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const [showRsvpList, setShowRsvpList] = useState(false);
  const [rsvpFilter, setRsvpFilter] = useState<"all" | "present" | "absent" | "maybe" | "pending">("all");

  const group = state.groups.find((g) => g.id === id);
  if (!group) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-muted">Groupe non trouvé</Text>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
          <Text style={{ color: colors.primary, marginTop: 10, fontWeight: "600" }}>Retour</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  const isAdmin = group.createdBy === (state.profile?.id || "user_1");
  const myMember = group.members.find((m) => m.id === state.profile?.id);
  const presentCount = group.members.filter((m) => m.rsvp === "present").length;
  const absentCount = group.members.filter((m) => m.rsvp === "absent").length;
  const maybeCount = group.members.filter((m) => m.rsvp === "maybe").length;
  const pendingCount = group.members.filter((m) => m.rsvp === "pending").length;
  const groupTasks = state.tasks.filter((t) => t.groupId === id);
  const groupMessages = state.chatMessages.filter((m) => m.groupId === id);

  const filteredMembers = rsvpFilter === "all"
    ? group.members
    : group.members.filter((m) => m.rsvp === rsvpFilter);

  const handleRsvp = (rsvp: "present" | "absent" | "maybe") => {
    if (state.profile) {
      dispatch({
        type: "UPDATE_RSVP",
        payload: { groupId: id!, memberId: state.profile.id, rsvp },
      });
    }
  };

  const handleLeaveGroup = () => {
    const doLeave = () => {
      // Remove self from members
      const updatedMembers = group.members.filter((m) => m.id !== state.profile?.id);
      dispatch({
        type: "UPDATE_GROUP",
        payload: { id: id!, updates: { members: updatedMembers } },
      });
      dispatch({
        type: "ADD_NOTIFICATION",
        payload: {
          id: generateId(),
          type: "reminder",
          title: "Groupe quitté",
          message: `Vous avez quitté "${group.name}"`,
          groupId: id!,
          read: false,
          createdAt: new Date().toISOString(),
        },
      });
      router.back();
    };

    if (Platform.OS === "web") {
      if (confirm("Voulez-vous vraiment quitter ce groupe ?")) doLeave();
    } else {
      Alert.alert("Quitter le groupe", "Voulez-vous vraiment quitter ce groupe ?", [
        { text: "Annuler", style: "cancel" },
        { text: "Quitter", style: "destructive", onPress: doLeave },
      ]);
    }
  };

  const handleCancelEvent = () => {
    const doCancel = () => {
      // Notify all members
      group.members.forEach((member) => {
        if (member.id !== state.profile?.id) {
          dispatch({
            type: "ADD_NOTIFICATION",
            payload: {
              id: generateId(),
              type: "reminder",
              title: "Soirée annulée",
              message: `L'organisateur a annulé "${group.name}"`,
              groupId: id!,
              read: false,
              createdAt: new Date().toISOString(),
            },
          });
        }
      });
      dispatch({ type: "DELETE_GROUP", payload: id! });
      router.back();
    };

    if (Platform.OS === "web") {
      if (confirm("Voulez-vous vraiment annuler cette soirée ? Tous les membres seront notifiés.")) doCancel();
    } else {
      Alert.alert(
        "Annuler la soirée",
        "Tous les membres seront notifiés. Cette action est irréversible.",
        [
          { text: "Non", style: "cancel" },
          { text: "Annuler la soirée", style: "destructive", onPress: doCancel },
        ]
      );
    }
  };

  const handleChangeBanner = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]) {
        dispatch({
          type: "UPDATE_GROUP",
          payload: { id: id!, updates: { coverImage: result.assets[0].uri } },
        });
      }
    } catch {
      // Fallback
    }
  };

  const modules = [
    { icon: "bubble.left.fill" as const, label: "Chat", color: "#06B6D4", route: `/group/chat?groupId=${id}`, badge: groupMessages.length },
    { icon: "cart.fill" as const, label: "Courses", color: "#10B981", route: `/group/shopping?groupId=${id}`, badge: 0 },
    { icon: "car.fill" as const, label: "Covoiturage", color: "#3B82F6", route: `/group/carpool?groupId=${id}`, badge: 0 },
    { icon: "photo.fill" as const, label: "Album", color: "#EC4899", route: `/group/album?groupId=${id}`, badge: 0 },
    { icon: "checkmark.circle.fill" as const, label: "Tâches", color: "#7C3AED", route: `/group/tasks?groupId=${id}`, badge: groupTasks.filter((t) => !t.completed).length },
    { icon: "location.fill" as const, label: "Localisation", color: "#F97316", route: `/group/location?groupId=${id}`, badge: 0 },
  ];

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="flex-row items-center gap-3 px-5 pt-2 pb-2">
          <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
            <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
          </Pressable>
          <Text className="text-foreground text-lg font-bold" style={{ flex: 1 }} numberOfLines={1}>
            {group.name}
          </Text>
          {/* Share button */}
          <Pressable
            onPress={() => router.push(`/group/share?groupId=${id}` as any)}
            style={({ pressed }) => [
              {
                width: 36,
                height: 36,
                borderRadius: 12,
                backgroundColor: colors.primary + "15",
                alignItems: "center",
                justifyContent: "center",
              },
              pressed && { opacity: 0.7 },
            ]}
          >
            <IconSymbol name="paperplane.fill" size={16} color={colors.primary} />
          </Pressable>
          {group.type === "auto-destruct" && (
            <View
              style={{
                backgroundColor: "#F97316",
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 10,
                flexDirection: "row",
                alignItems: "center",
                gap: 4,
              }}
            >
              <IconSymbol name="timer" size={12} color="#FFF" />
              <Text style={{ color: "#FFF", fontSize: 11, fontWeight: "600" }}>
                {getTimeRemaining(group.expiresAt!)}
              </Text>
            </View>
          )}
        </View>

        {/* Cover / Banner */}
        <View className="px-5 mb-4">
          <Pressable onPress={isAdmin ? handleChangeBanner : undefined}>
            <View
              style={{
                height: 160,
                borderRadius: 20,
                backgroundColor: colors.primary,
                justifyContent: "flex-end",
                padding: 16,
                overflow: "hidden",
              }}
            >
              {group.coverImage ? (
                <View style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}>
                  <Image
                    source={{ uri: group.coverImage }}
                    style={{ width: "100%", height: "100%" }}
                    contentFit="cover"
                    transition={200}
                  />
                  <View style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(0,0,0,0.35)" }} />
                </View>
              ) : null}
              {isAdmin && (
                <View
                  style={{
                    position: "absolute",
                    top: 12,
                    right: 12,
                    backgroundColor: "rgba(0,0,0,0.5)",
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    borderRadius: 10,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 4,
                  }}
                >
                  <IconSymbol name="photo.fill" size={12} color="#FFF" />
                  <Text style={{ color: "#FFF", fontSize: 10, fontWeight: "600" }}>Modifier</Text>
                </View>
              )}
              <Text style={{ color: "#FFF", fontSize: 22, fontWeight: "800" }}>{group.name}</Text>
              <Text style={{ color: "#FFFFFFCC", fontSize: 13, marginTop: 4 }}>
                {formatDate(group.date)} · {group.time}
              </Text>
              <Text style={{ color: "#FFFFFFCC", fontSize: 13, marginTop: 2 }}>
                📍 {group.location}
              </Text>
            </View>
          </Pressable>
        </View>

        {/* Description */}
        {group.description ? (
          <View className="px-5 mb-4">
            <Text className="text-muted text-sm">{group.description}</Text>
          </View>
        ) : null}

        {/* RSVP */}
        <View className="px-5 mb-5">
          <Text className="text-foreground font-bold mb-3">Votre réponse</Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {(["present", "absent", "maybe"] as const).map((rsvp) => {
              const config = RSVP_CONFIG[rsvp];
              const isActive = myMember?.rsvp === rsvp;
              return (
                <Pressable
                  key={rsvp}
                  onPress={() => handleRsvp(rsvp)}
                  style={({ pressed }) => [
                    {
                      flex: 1,
                      paddingVertical: 12,
                      borderRadius: 12,
                      alignItems: "center",
                      backgroundColor: isActive ? config.color + "20" : colors.surface,
                      borderWidth: 2,
                      borderColor: isActive ? config.color : colors.border,
                    },
                    pressed && { opacity: 0.8 },
                  ]}
                >
                  <Text style={{ fontSize: 18, marginBottom: 4 }}>{config.emoji}</Text>
                  <Text style={{ fontWeight: "600", fontSize: 12, color: isActive ? config.color : colors.foreground }}>
                    {config.label}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {/* RSVP Summary - Clickable to expand */}
          <Pressable
            onPress={() => setShowRsvpList(!showRsvpList)}
            style={({ pressed }) => [
              {
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
                marginTop: 10,
                gap: 16,
                paddingVertical: 8,
                borderRadius: 10,
                backgroundColor: colors.surface,
              },
              pressed && { opacity: 0.8 },
            ]}
          >
            <Text style={{ color: "#10B981", fontSize: 12, fontWeight: "600" }}>✅ {presentCount}</Text>
            <Text style={{ color: "#EF4444", fontSize: 12, fontWeight: "600" }}>❌ {absentCount}</Text>
            <Text style={{ color: "#F59E0B", fontSize: 12, fontWeight: "600" }}>🤔 {maybeCount}</Text>
            <Text style={{ color: "#6B7280", fontSize: 12, fontWeight: "600" }}>⏳ {pendingCount}</Text>
            <IconSymbol name={showRsvpList ? "chevron.up" : "chevron.down"} size={14} color={colors.muted} />
          </Pressable>
        </View>

        {/* RSVP Detailed List */}
        {showRsvpList && (
          <View className="px-5 mb-5">
            <View style={{ flexDirection: "row", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
              {(["all", "present", "absent", "maybe", "pending"] as const).map((filter) => {
                const labels: Record<string, string> = {
                  all: "Tous",
                  present: `Présents (${presentCount})`,
                  absent: `Absents (${absentCount})`,
                  maybe: `Peut-être (${maybeCount})`,
                  pending: `En attente (${pendingCount})`,
                };
                const filterColors: Record<string, string> = {
                  all: colors.primary,
                  present: "#10B981",
                  absent: "#EF4444",
                  maybe: "#F59E0B",
                  pending: "#6B7280",
                };
                const isActive = rsvpFilter === filter;
                return (
                  <Pressable
                    key={filter}
                    onPress={() => setRsvpFilter(filter)}
                    style={({ pressed }) => [
                      {
                        paddingHorizontal: 12,
                        paddingVertical: 6,
                        borderRadius: 20,
                        backgroundColor: isActive ? filterColors[filter] + "20" : colors.surface,
                        borderWidth: 1,
                        borderColor: isActive ? filterColors[filter] : colors.border,
                      },
                      pressed && { opacity: 0.8 },
                    ]}
                  >
                    <Text style={{ color: isActive ? filterColors[filter] : colors.muted, fontSize: 11, fontWeight: "600" }}>
                      {labels[filter]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            {filteredMembers.map((member) => {
              const rsvpConfig = RSVP_CONFIG[member.rsvp];
              return (
                <View
                  key={member.id}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    padding: 10,
                    borderRadius: 12,
                    marginBottom: 4,
                    backgroundColor: colors.surface,
                    borderWidth: 1,
                    borderColor: colors.border,
                  }}
                >
                  <View
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 18,
                      backgroundColor: rsvpConfig.color + "20",
                      alignItems: "center",
                      justifyContent: "center",
                      marginRight: 10,
                    }}
                  >
                    <Text style={{ fontWeight: "700", color: rsvpConfig.color, fontSize: 14 }}>
                      {member.name.charAt(0)}
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                      <Text className="text-foreground font-semibold text-sm">{member.name}</Text>
                      {member.role === "admin" && (
                        <View style={{ backgroundColor: colors.warning + "20", paddingHorizontal: 6, paddingVertical: 1, borderRadius: 6 }}>
                          <Text style={{ color: colors.warning, fontSize: 9, fontWeight: "700" }}>ADMIN</Text>
                        </View>
                      )}
                    </View>
                    <Text className="text-muted text-xs">@{member.username}</Text>
                  </View>
                  <View style={{ backgroundColor: rsvpConfig.color + "15", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 }}>
                    <Text style={{ color: rsvpConfig.color, fontSize: 11, fontWeight: "600" }}>
                      {rsvpConfig.emoji} {rsvpConfig.label}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* Modules Grid */}
        <View className="px-5 mb-5">
          <Text className="text-foreground font-bold mb-3">Modules</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
            {modules.map((mod) => (
              <Pressable
                key={mod.label}
                onPress={() => router.push(mod.route as any)}
                style={({ pressed }) => [
                  {
                    width: "31%",
                    backgroundColor: colors.surface,
                    borderRadius: 16,
                    padding: 14,
                    alignItems: "center",
                    borderWidth: 1,
                    borderColor: colors.border,
                  },
                  pressed && { opacity: 0.7, transform: [{ scale: 0.97 }] },
                ]}
              >
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 14,
                    backgroundColor: mod.color + "15",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 6,
                  }}
                >
                  <IconSymbol name={mod.icon} size={22} color={mod.color} />
                  {mod.badge > 0 && (
                    <View
                      style={{
                        position: "absolute",
                        top: -4,
                        right: -4,
                        backgroundColor: colors.error,
                        width: 18,
                        height: 18,
                        borderRadius: 9,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Text style={{ color: "#FFF", fontSize: 9, fontWeight: "700" }}>{mod.badge > 9 ? "9+" : mod.badge}</Text>
                    </View>
                  )}
                </View>
                <Text style={{ color: colors.foreground, fontWeight: "600", fontSize: 12, textAlign: "center" }}>
                  {mod.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Sondages */}
        <View className="px-5 mb-5">
          <View className="flex-row items-center justify-between mb-3">
            <Text className="text-foreground font-bold">Sondages</Text>
            <Pressable
              onPress={() => router.push(`/group/polls?groupId=${id}` as any)}
              style={({ pressed }) => [pressed && { opacity: 0.7 }]}
            >
              <Text style={{ color: colors.primary, fontWeight: "600", fontSize: 13 }}>Voir tout</Text>
            </Pressable>
          </View>
          {state.polls.filter((p) => p.groupId === id).length === 0 ? (
            <View
              style={{
                backgroundColor: colors.surface,
                borderRadius: 14,
                padding: 16,
                alignItems: "center",
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Text className="text-muted text-sm">Aucun sondage pour le moment</Text>
            </View>
          ) : (
            state.polls
              .filter((p) => p.groupId === id)
              .slice(0, 2)
              .map((poll) => {
                const totalVotes = poll.options.reduce((sum, o) => sum + o.votes.length, 0);
                return (
                  <View
                    key={poll.id}
                    style={{
                      backgroundColor: colors.surface,
                      borderRadius: 14,
                      padding: 14,
                      marginBottom: 8,
                      borderWidth: 1,
                      borderColor: colors.border,
                    }}
                  >
                    <Text className="text-foreground font-semibold text-sm mb-3">{poll.question}</Text>
                    {poll.options.map((opt) => {
                      const pct = totalVotes > 0 ? (opt.votes.length / totalVotes) * 100 : 0;
                      const voted = opt.votes.includes(state.profile?.id || "");
                      return (
                        <Pressable
                          key={opt.id}
                          onPress={() =>
                            dispatch({
                              type: "VOTE_POLL",
                              payload: { pollId: poll.id, optionId: opt.id, userId: state.profile?.id || "user_1" },
                            })
                          }
                          style={({ pressed }) => [
                            {
                              marginBottom: 6,
                              borderRadius: 10,
                              overflow: "hidden",
                              borderWidth: 1,
                              borderColor: voted ? colors.primary : colors.border,
                            },
                            pressed && { opacity: 0.8 },
                          ]}
                        >
                          <View
                            style={{
                              position: "absolute",
                              left: 0,
                              top: 0,
                              bottom: 0,
                              width: `${pct}%`,
                              backgroundColor: voted ? colors.primary + "20" : colors.border + "30",
                            }}
                          />
                          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 10 }}>
                            <Text style={{ color: voted ? colors.primary : colors.foreground, fontWeight: voted ? "700" : "500", fontSize: 13 }}>
                              {opt.text}
                            </Text>
                            <Text style={{ color: colors.muted, fontSize: 12 }}>{Math.round(pct)}%</Text>
                          </View>
                        </Pressable>
                      );
                    })}
                  </View>
                );
              })
          )}
        </View>

        {/* Invitation Code */}
        <View className="px-5 mb-5">
          <Text className="text-foreground font-bold mb-3">Inviter des amis</Text>
          <View
            style={{
              backgroundColor: colors.surface,
              borderRadius: 14,
              padding: 14,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <Text className="text-muted text-xs mb-2">Code d'invitation</Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
              <View style={{ flex: 1, backgroundColor: colors.background, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 }}>
                <Text className="text-foreground font-bold text-lg">{group.invitationCode}</Text>
              </View>
              <Pressable
                onPress={() => {
                  if (Platform.OS === "web") {
                    navigator.clipboard.writeText(group.invitationCode);
                    alert("Code copié !");
                  } else {
                    Alert.alert("Code d'invitation", group.invitationCode, [
                      { text: "Copier", onPress: () => {} },
                      { text: "Fermer", style: "cancel" },
                    ]);
                  }
                }}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View style={{ backgroundColor: colors.primary, borderRadius: 10, padding: 10 }}>
                  <IconSymbol name="doc.on.doc" size={18} color="#FFF" />
                </View>
              </Pressable>
            </View>
            <Text className="text-muted text-xs mt-2">Partagez ce code avec vos amis pour qu'ils rejoignent la soirée</Text>
          </View>
        </View>

        {/* Leave / Cancel Actions */}
        <View className="px-5 mb-5" style={{ gap: 8 }}>
          {isAdmin ? (
            <Pressable
              onPress={handleCancelEvent}
              style={({ pressed }) => [
                {
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  padding: 14,
                  borderRadius: 14,
                  backgroundColor: colors.error + "10",
                  borderWidth: 1,
                  borderColor: colors.error + "40",
                  gap: 8,
                },
                pressed && { opacity: 0.8 },
              ]}
            >
              <IconSymbol name="xmark.circle.fill" size={18} color={colors.error} />
              <Text style={{ color: colors.error, fontWeight: "700", fontSize: 14 }}>
                Annuler la soirée
              </Text>
            </Pressable>
          ) : (
            <Pressable
              onPress={handleLeaveGroup}
              style={({ pressed }) => [
                {
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  padding: 14,
                  borderRadius: 14,
                  backgroundColor: colors.error + "10",
                  borderWidth: 1,
                  borderColor: colors.error + "40",
                  gap: 8,
                },
                pressed && { opacity: 0.8 },
              ]}
            >
              <IconSymbol name="arrow.right.square" size={18} color={colors.error} />
              <Text style={{ color: colors.error, fontWeight: "700", fontSize: 14 }}>
                Quitter le groupe
              </Text>
            </Pressable>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
