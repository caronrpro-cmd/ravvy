import { useState } from "react";
import { Text, View, Pressable, ScrollView, TextInput, Platform, Alert } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useApp, generateId } from "@/lib/app-provider";

type Mode = "list" | "who-brings" | "tricount";

export default function ShoppingScreen() {
  const { state, dispatch } = useApp();
  const colors = useColors();
  const router = useRouter();
  const { groupId } = useLocalSearchParams<{ groupId: string }>();

  const [mode, setMode] = useState<Mode>("list");
  const [newItem, setNewItem] = useState("");
  const [newPrice, setNewPrice] = useState("");
  const [newExpDesc, setNewExpDesc] = useState("");
  const [newExpAmount, setNewExpAmount] = useState("");
  const [newExpPaidBy, setNewExpPaidBy] = useState("");
  const [assigningItem, setAssigningItem] = useState<string | null>(null);

  const group = state.groups.find((g) => g.id === groupId);
  const items = state.shoppingItems.filter((i) => i.groupId === groupId);
  const expenses = state.expenses.filter((e) => e.groupId === groupId);

  const totalItems = items.reduce((sum, i) => sum + i.price, 0);
  const boughtItems = items.filter((i) => i.status === "bought");

  // Tricount calculations
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const memberBalances: Record<string, number> = {};
  if (group) {
    group.members.forEach((m) => { memberBalances[m.id] = 0; });
    expenses.forEach((exp) => {
      const share = exp.amount / exp.splitBetween.length;
      memberBalances[exp.paidBy] = (memberBalances[exp.paidBy] || 0) + exp.amount;
      exp.splitBetween.forEach((uid) => { memberBalances[uid] = (memberBalances[uid] || 0) - share; });
    });
  }

  // Who brings what - group items by assignee
  const itemsByMember: Record<string, typeof items> = {};
  const unassignedItems = items.filter((i) => !i.assignedTo);
  if (group) {
    group.members.forEach((m) => {
      const memberItems = items.filter((i) => i.assignedTo === m.id);
      if (memberItems.length > 0) itemsByMember[m.id] = memberItems;
    });
  }

  const getMemberName = (id: string) => {
    const member = group?.members.find((m) => m.id === id);
    return member?.name || "Inconnu";
  };

  const handleAddItem = () => {
    if (!newItem.trim()) return;
    dispatch({
      type: "ADD_SHOPPING_ITEM",
      payload: {
        id: generateId(),
        groupId: groupId!,
        name: newItem.trim(),
        status: "to_buy",
        price: parseFloat(newPrice) || 0,
        addedBy: state.profile?.id || "user_1",
        createdAt: new Date().toISOString(),
      },
    });
    setNewItem("");
    setNewPrice("");
  };

  const handleAssignItem = (itemId: string, memberId: string | null) => {
    dispatch({
      type: "UPDATE_SHOPPING_ITEM",
      payload: { id: itemId, updates: { assignedTo: memberId || undefined } },
    });
    setAssigningItem(null);
  };

  const handleTakeItem = (itemId: string) => {
    const userId = state.profile?.id || "user_1";
    const item = items.find((i) => i.id === itemId);
    if (item?.assignedTo === userId) {
      handleAssignItem(itemId, null);
    } else {
      handleAssignItem(itemId, userId);
    }
  };

  const handleAddExpense = () => {
    if (!newExpDesc.trim() || !newExpAmount) return;
    const paidBy = newExpPaidBy || state.profile?.id || "user_1";
    dispatch({
      type: "ADD_EXPENSE",
      payload: {
        id: generateId(),
        groupId: groupId!,
        description: newExpDesc.trim(),
        amount: parseFloat(newExpAmount) || 0,
        paidBy,
        splitBetween: group?.members.map((m) => m.id) || [],
        createdAt: new Date().toISOString(),
      },
    });
    setNewExpDesc("");
    setNewExpAmount("");
    setNewExpPaidBy("");
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View className="flex-row items-center gap-3 px-5 pt-2 pb-3">
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
          <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
        </Pressable>
        <Text className="text-foreground text-xl font-bold" style={{ flex: 1 }}>Courses</Text>
      </View>

      {/* Mode Toggle - 3 modes */}
      <View className="px-5 mb-4">
        <View style={{ flexDirection: "row", backgroundColor: colors.surface, borderRadius: 12, padding: 3, borderWidth: 1, borderColor: colors.border }}>
          {[
            { key: "list" as Mode, label: "Liste", icon: "list.bullet" as const },
            { key: "who-brings" as Mode, label: "Qui prend quoi", icon: "person.2.fill" as const },
            { key: "tricount" as Mode, label: "Tricount", icon: "dollarsign.circle.fill" as const },
          ].map((m) => (
            <Pressable
              key={m.key}
              onPress={() => setMode(m.key)}
              style={({ pressed }) => [
                {
                  flex: 1,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 4,
                  paddingVertical: 10,
                  borderRadius: 10,
                  backgroundColor: mode === m.key ? colors.primary : "transparent",
                },
                pressed && { opacity: 0.8 },
              ]}
            >
              <IconSymbol name={m.icon} size={14} color={mode === m.key ? "#FFF" : colors.muted} />
              <Text style={{ color: mode === m.key ? "#FFF" : colors.muted, fontWeight: "600", fontSize: 11 }}>
                {m.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
        {mode === "list" ? (
          <>
            {/* Summary */}
            <View className="px-5 mb-4">
              <View style={{ flexDirection: "row", gap: 10 }}>
                <View style={{ flex: 1, backgroundColor: colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center" }}>
                  <Text className="text-foreground text-xl font-bold">{items.length}</Text>
                  <Text className="text-muted text-xs">Articles</Text>
                </View>
                <View style={{ flex: 1, backgroundColor: colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center" }}>
                  <Text className="text-foreground text-xl font-bold">{boughtItems.length}</Text>
                  <Text className="text-muted text-xs">Achetés</Text>
                </View>
                <View style={{ flex: 1, backgroundColor: colors.primary + "15", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.primary + "30", alignItems: "center" }}>
                  <Text style={{ color: colors.primary, fontSize: 18, fontWeight: "700" }}>{totalItems.toFixed(0)}€</Text>
                  <Text className="text-muted text-xs">Total</Text>
                </View>
              </View>
            </View>

            {/* Add Item */}
            <View className="px-5 mb-4">
              <View style={{ flexDirection: "row", gap: 8 }}>
                <TextInput
                  placeholder="Ajouter un article..."
                  placeholderTextColor={colors.muted}
                  value={newItem}
                  onChangeText={setNewItem}
                  returnKeyType="done"
                  onSubmitEditing={handleAddItem}
                  style={{ flex: 1, backgroundColor: colors.surface, borderRadius: 12, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border }}
                />
                <TextInput
                  placeholder="Prix"
                  placeholderTextColor={colors.muted}
                  value={newPrice}
                  onChangeText={setNewPrice}
                  keyboardType="numeric"
                  style={{ width: 70, backgroundColor: colors.surface, borderRadius: 12, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border, textAlign: "center" }}
                />
                <Pressable
                  onPress={handleAddItem}
                  style={({ pressed }) => [
                    { backgroundColor: colors.primary, borderRadius: 12, width: 44, alignItems: "center", justifyContent: "center" },
                    pressed && { opacity: 0.7 },
                  ]}
                >
                  <IconSymbol name="plus" size={20} color="#FFF" />
                </Pressable>
              </View>
            </View>

            {/* Items List */}
            <View className="px-5">
              {items.map((item) => (
                <View key={item.id}>
                  <Pressable
                    onPress={() =>
                      dispatch({
                        type: "UPDATE_SHOPPING_ITEM",
                        payload: { id: item.id, updates: { status: item.status === "bought" ? "to_buy" : "bought" } },
                      })
                    }
                    style={({ pressed }) => [
                      {
                        flexDirection: "row",
                        alignItems: "center",
                        padding: 12,
                        borderRadius: 12,
                        marginBottom: assigningItem === item.id ? 0 : 6,
                        backgroundColor: colors.surface,
                        borderWidth: 1,
                        borderColor: colors.border,
                        opacity: item.status === "bought" ? 0.6 : 1,
                      },
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    <View
                      style={{
                        width: 24,
                        height: 24,
                        borderRadius: 12,
                        borderWidth: 2,
                        borderColor: item.status === "bought" ? colors.success : colors.border,
                        backgroundColor: item.status === "bought" ? colors.success : "transparent",
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 10,
                      }}
                    >
                      {item.status === "bought" && <IconSymbol name="checkmark" size={14} color="#FFF" />}
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          color: colors.foreground,
                          fontWeight: "500",
                          fontSize: 14,
                          textDecorationLine: item.status === "bought" ? "line-through" : "none",
                        }}
                      >
                        {item.name}
                      </Text>
                      {item.assignedTo && (
                        <Text style={{ color: colors.primary, fontSize: 11, marginTop: 2, fontWeight: "500" }}>
                          {getMemberName(item.assignedTo)} s'en charge
                        </Text>
                      )}
                    </View>
                    {item.price > 0 && (
                      <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 14, marginRight: 6 }}>{item.price}€</Text>
                    )}
                    {/* Assign button */}
                    <Pressable
                      onPress={() => setAssigningItem(assigningItem === item.id ? null : item.id)}
                      style={({ pressed }) => [{ marginRight: 6 }, pressed && { opacity: 0.5 }]}
                    >
                      <IconSymbol name="person.fill" size={14} color={item.assignedTo ? colors.primary : colors.muted} />
                    </Pressable>
                    <Pressable
                      onPress={() => dispatch({ type: "DELETE_SHOPPING_ITEM", payload: item.id })}
                      style={({ pressed }) => [pressed && { opacity: 0.5 }]}
                    >
                      <IconSymbol name="xmark" size={14} color={colors.muted} />
                    </Pressable>
                  </Pressable>

                  {/* Assign dropdown */}
                  {assigningItem === item.id && (
                    <View style={{ marginBottom: 6, marginLeft: 34, backgroundColor: colors.surface, borderRadius: 10, padding: 8, borderWidth: 1, borderColor: colors.primary + "40" }}>
                      <Text style={{ color: colors.muted, fontSize: 10, marginBottom: 6 }}>Assigner à :</Text>
                      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
                        <Pressable
                          onPress={() => handleTakeItem(item.id)}
                          style={({ pressed }) => [
                            {
                              paddingHorizontal: 10,
                              paddingVertical: 5,
                              borderRadius: 8,
                              backgroundColor: colors.primary,
                            },
                            pressed && { opacity: 0.7 },
                          ]}
                        >
                          <Text style={{ color: "#FFF", fontSize: 11, fontWeight: "600" }}>
                            {item.assignedTo === (state.profile?.id || "user_1") ? "Me retirer" : "Je m'en charge"}
                          </Text>
                        </Pressable>
                        {group?.members.filter((m) => m.id !== (state.profile?.id || "user_1")).map((m) => (
                          <Pressable
                            key={m.id}
                            onPress={() => handleAssignItem(item.id, m.id)}
                            style={({ pressed }) => [
                              {
                                paddingHorizontal: 10,
                                paddingVertical: 5,
                                borderRadius: 8,
                                backgroundColor: item.assignedTo === m.id ? colors.primary + "25" : colors.background,
                                borderWidth: 1,
                                borderColor: item.assignedTo === m.id ? colors.primary : colors.border,
                              },
                              pressed && { opacity: 0.7 },
                            ]}
                          >
                            <Text style={{ color: item.assignedTo === m.id ? colors.primary : colors.foreground, fontSize: 11, fontWeight: "500" }}>
                              {m.name.split(" ")[0]}
                            </Text>
                          </Pressable>
                        ))}
                      </View>
                    </View>
                  )}
                </View>
              ))}
            </View>
          </>
        ) : mode === "who-brings" ? (
          <>
            {/* Who Brings What View */}
            <View className="px-5 mb-4">
              <View style={{ backgroundColor: colors.primary + "10", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.primary + "25" }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <IconSymbol name="person.2.fill" size={20} color={colors.primary} />
                  <View>
                    <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 15 }}>Répartition des courses</Text>
                    <Text style={{ color: colors.muted, fontSize: 11, marginTop: 2 }}>
                      {items.filter((i) => i.assignedTo).length}/{items.length} articles assignés
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            {/* Members with their items */}
            {group?.members.map((member) => {
              const memberItems = items.filter((i) => i.assignedTo === member.id);
              if (memberItems.length === 0) return null;
              const memberTotal = memberItems.reduce((sum, i) => sum + i.price, 0);
              const boughtCount = memberItems.filter((i) => i.status === "bought").length;
              return (
                <View key={member.id} className="px-5 mb-4">
                  <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: colors.border }}>
                    {/* Member header */}
                    <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}>
                      <View
                        style={{
                          width: 36,
                          height: 36,
                          borderRadius: 18,
                          backgroundColor: colors.primary + "25",
                          alignItems: "center",
                          justifyContent: "center",
                          marginRight: 10,
                        }}
                      >
                        <Text style={{ fontWeight: "700", color: colors.primary, fontSize: 14 }}>{member.name.charAt(0)}</Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 14 }}>{member.name}</Text>
                        <Text style={{ color: colors.muted, fontSize: 11 }}>
                          {boughtCount}/{memberItems.length} achetés
                        </Text>
                      </View>
                      {memberTotal > 0 && (
                        <View style={{ backgroundColor: colors.primary + "15", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 }}>
                          <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 13 }}>{memberTotal.toFixed(0)}€</Text>
                        </View>
                      )}
                    </View>
                    {/* Member's items */}
                    {memberItems.map((item) => (
                      <Pressable
                        key={item.id}
                        onPress={() =>
                          dispatch({
                            type: "UPDATE_SHOPPING_ITEM",
                            payload: { id: item.id, updates: { status: item.status === "bought" ? "to_buy" : "bought" } },
                          })
                        }
                        style={({ pressed }) => [
                          {
                            flexDirection: "row",
                            alignItems: "center",
                            paddingVertical: 8,
                            paddingHorizontal: 6,
                            borderRadius: 8,
                            marginBottom: 2,
                            opacity: item.status === "bought" ? 0.5 : 1,
                          },
                          pressed && { opacity: 0.6 },
                        ]}
                      >
                        <View
                          style={{
                            width: 20,
                            height: 20,
                            borderRadius: 10,
                            borderWidth: 2,
                            borderColor: item.status === "bought" ? colors.success : colors.border,
                            backgroundColor: item.status === "bought" ? colors.success : "transparent",
                            alignItems: "center",
                            justifyContent: "center",
                            marginRight: 8,
                          }}
                        >
                          {item.status === "bought" && <IconSymbol name="checkmark" size={10} color="#FFF" />}
                        </View>
                        <Text
                          style={{
                            flex: 1,
                            color: colors.foreground,
                            fontSize: 13,
                            textDecorationLine: item.status === "bought" ? "line-through" : "none",
                          }}
                        >
                          {item.name}
                        </Text>
                        {item.price > 0 && (
                          <Text style={{ color: colors.muted, fontSize: 12 }}>{item.price}€</Text>
                        )}
                      </Pressable>
                    ))}
                  </View>
                </View>
              );
            })}

            {/* Unassigned items */}
            {unassignedItems.length > 0 && (
              <View className="px-5 mb-4">
                <View style={{ backgroundColor: colors.surface, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: colors.warning + "40" }}>
                  <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}>
                    <View
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: 18,
                        backgroundColor: colors.warning + "20",
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ fontSize: 16 }}>❓</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: colors.foreground, fontWeight: "700", fontSize: 14 }}>Non assignés</Text>
                      <Text style={{ color: colors.warning, fontSize: 11 }}>{unassignedItems.length} articles</Text>
                    </View>
                  </View>
                  {unassignedItems.map((item) => (
                    <Pressable
                      key={item.id}
                      onPress={() => handleTakeItem(item.id)}
                      style={({ pressed }) => [
                        {
                          flexDirection: "row",
                          alignItems: "center",
                          paddingVertical: 8,
                          paddingHorizontal: 6,
                          borderRadius: 8,
                          marginBottom: 2,
                        },
                        pressed && { opacity: 0.6 },
                      ]}
                    >
                      <View
                        style={{
                          width: 20,
                          height: 20,
                          borderRadius: 10,
                          borderWidth: 2,
                          borderColor: colors.warning,
                          backgroundColor: "transparent",
                          alignItems: "center",
                          justifyContent: "center",
                          marginRight: 8,
                        }}
                      >
                        <Text style={{ fontSize: 8, color: colors.warning }}>?</Text>
                      </View>
                      <Text style={{ flex: 1, color: colors.foreground, fontSize: 13 }}>{item.name}</Text>
                      {item.price > 0 && (
                        <Text style={{ color: colors.muted, fontSize: 12, marginRight: 6 }}>{item.price}€</Text>
                      )}
                      <View style={{ backgroundColor: colors.primary + "15", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 }}>
                        <Text style={{ color: colors.primary, fontSize: 10, fontWeight: "600" }}>Je prends</Text>
                      </View>
                    </Pressable>
                  ))}
                </View>
              </View>
            )}

            {items.length === 0 && (
              <View className="items-center py-12">
                <IconSymbol name="cart.fill" size={48} color={colors.muted} />
                <Text className="text-muted mt-3 text-center">Ajoutez des articles dans l'onglet Liste</Text>
              </View>
            )}
          </>
        ) : (
          <>
            {/* Tricount Summary */}
            <View className="px-5 mb-4">
              <View style={{ backgroundColor: colors.primary + "15", borderRadius: 14, padding: 16, borderWidth: 1, borderColor: colors.primary + "30", alignItems: "center" }}>
                <Text style={{ color: colors.primary, fontSize: 28, fontWeight: "800" }}>{totalExpenses.toFixed(2)}€</Text>
                <Text className="text-muted text-sm mt-1">Total des dépenses</Text>
              </View>
            </View>

            {/* Add Expense */}
            <View className="px-5 mb-4">
              <View style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border }}>
                <TextInput
                  placeholder="Description de la dépense"
                  placeholderTextColor={colors.muted}
                  value={newExpDesc}
                  onChangeText={setNewExpDesc}
                  style={{ backgroundColor: colors.background, borderRadius: 10, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border, marginBottom: 8 }}
                />
                <View style={{ flexDirection: "row", gap: 8, marginBottom: 8 }}>
                  <TextInput
                    placeholder="Montant (€)"
                    placeholderTextColor={colors.muted}
                    value={newExpAmount}
                    onChangeText={setNewExpAmount}
                    keyboardType="numeric"
                    style={{ flex: 1, backgroundColor: colors.background, borderRadius: 10, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border }}
                  />
                </View>
                <Text className="text-muted text-xs mb-2">Payé par : {getMemberName(newExpPaidBy || state.profile?.id || "user_1")}</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
                  <View style={{ flexDirection: "row", gap: 6 }}>
                    {group?.members.map((m) => (
                      <Pressable
                        key={m.id}
                        onPress={() => setNewExpPaidBy(m.id)}
                        style={({ pressed }) => [
                          {
                            paddingHorizontal: 12,
                            paddingVertical: 6,
                            borderRadius: 8,
                            backgroundColor: (newExpPaidBy || state.profile?.id) === m.id ? colors.primary : colors.background,
                            borderWidth: 1,
                            borderColor: (newExpPaidBy || state.profile?.id) === m.id ? colors.primary : colors.border,
                          },
                          pressed && { opacity: 0.7 },
                        ]}
                      >
                        <Text style={{ color: (newExpPaidBy || state.profile?.id) === m.id ? "#FFF" : colors.foreground, fontSize: 12, fontWeight: "600" }}>
                          {m.name.split(" ")[0]}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </ScrollView>
                <Pressable
                  onPress={handleAddExpense}
                  style={({ pressed }) => [
                    { backgroundColor: colors.primary, borderRadius: 10, padding: 12, alignItems: "center" },
                    pressed && { opacity: 0.7 },
                  ]}
                >
                  <Text style={{ color: "#FFF", fontWeight: "600" }}>Ajouter la dépense</Text>
                </Pressable>
              </View>
            </View>

            {/* Balances */}
            <View className="px-5 mb-4">
              <Text className="text-foreground font-bold mb-3">Bilan</Text>
              {group?.members.map((m) => {
                const balance = memberBalances[m.id] || 0;
                return (
                  <View
                    key={m.id}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      padding: 12,
                      borderRadius: 12,
                      marginBottom: 6,
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: colors.border,
                    }}
                  >
                    <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: colors.primary + "25", alignItems: "center", justifyContent: "center", marginRight: 10 }}>
                      <Text style={{ fontWeight: "700", color: colors.primary, fontSize: 13 }}>{m.name.charAt(0)}</Text>
                    </View>
                    <Text className="text-foreground text-sm font-semibold" style={{ flex: 1 }}>{m.name}</Text>
                    <Text style={{ fontWeight: "700", fontSize: 14, color: balance >= 0 ? colors.success : colors.error }}>
                      {balance >= 0 ? "+" : ""}{balance.toFixed(2)}€
                    </Text>
                  </View>
                );
              })}
            </View>

            {/* Expenses List */}
            <View className="px-5">
              <Text className="text-foreground font-bold mb-3">Historique</Text>
              {expenses.map((exp) => (
                <View
                  key={exp.id}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    padding: 12,
                    borderRadius: 12,
                    marginBottom: 6,
                    backgroundColor: colors.surface,
                    borderWidth: 1,
                    borderColor: colors.border,
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text className="text-foreground font-semibold text-sm">{exp.description}</Text>
                    <Text className="text-muted text-xs mt-1">Payé par {getMemberName(exp.paidBy)}</Text>
                  </View>
                  <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 15 }}>{exp.amount.toFixed(2)}€</Text>
                </View>
              ))}
            </View>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
