import { useState } from "react";
import { Text, View, Pressable, ScrollView, TextInput, Alert, Platform } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useApp, generateId } from "@/lib/app-provider";

export default function PollsScreen() {
  const { state, dispatch } = useApp();
  const colors = useColors();
  const router = useRouter();
  const { groupId } = useLocalSearchParams<{ groupId: string }>();

  const [showCreate, setShowCreate] = useState(false);
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", ""]);

  const polls = state.polls.filter((p) => p.groupId === groupId);
  const group = state.groups.find((g) => g.id === groupId);
  const userId = state.profile?.id || "user_1";
  const isAdmin = group?.createdBy === userId;

  const handleCreate = () => {
    if (!question.trim() || options.filter((o) => o.trim()).length < 2) return;
    dispatch({
      type: "ADD_POLL",
      payload: {
        id: generateId(),
        groupId: groupId!,
        question: question.trim(),
        options: options
          .filter((o) => o.trim())
          .map((o) => ({ id: generateId(), text: o.trim(), votes: [] })),
        createdBy: userId,
        createdAt: new Date().toISOString(),
      },
    });
    setQuestion("");
    setOptions(["", ""]);
    setShowCreate(false);
  };

  const handleDeletePoll = (pollId: string) => {
    const doDelete = () => {
      dispatch({ type: "DELETE_POLL", payload: pollId });
    };
    if (Platform.OS === "web") {
      if (confirm("Supprimer ce sondage ?")) doDelete();
    } else {
      Alert.alert("Supprimer le sondage", "Cette action est irréversible.", [
        { text: "Annuler", style: "cancel" },
        { text: "Supprimer", style: "destructive", onPress: doDelete },
      ]);
    }
  };

  const handleVote = (pollId: string, optionId: string) => {
    const poll = polls.find((p) => p.id === pollId);
    if (!poll) return;

    // Check if user already voted for this option
    const option = poll.options.find((o) => o.id === optionId);
    if (option?.votes.includes(userId)) {
      // Unvote - remove from this option
      dispatch({ type: "UNVOTE_POLL", payload: { pollId, userId } });
      return;
    }

    // Vote (VOTE_POLL already removes from other options)
    dispatch({ type: "VOTE_POLL", payload: { pollId, optionId, userId } });
  };

  const handleRemoveMyVote = (pollId: string) => {
    dispatch({ type: "UNVOTE_POLL", payload: { pollId, userId } });
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
        <View className="flex-row items-center justify-between px-5 pt-2 pb-4">
          <View className="flex-row items-center gap-3">
            <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
              <IconSymbol name="chevron.left" size={24} color={colors.foreground} />
            </Pressable>
            <Text className="text-foreground text-xl font-bold">Sondages</Text>
          </View>
          <Pressable
            onPress={() => setShowCreate(!showCreate)}
            style={({ pressed }) => [
              { backgroundColor: colors.primary, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10 },
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={{ color: "#FFF", fontWeight: "600", fontSize: 13 }}>Nouveau</Text>
          </Pressable>
        </View>

        {showCreate && (
          <View className="px-5 mb-4">
            <View style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.primary }}>
              <TextInput
                placeholder="Votre question..."
                placeholderTextColor={colors.muted}
                value={question}
                onChangeText={setQuestion}
                style={{ backgroundColor: colors.background, borderRadius: 10, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border, marginBottom: 10 }}
              />
              {options.map((opt, i) => (
                <View key={i} style={{ flexDirection: "row", gap: 6, marginBottom: 6 }}>
                  <TextInput
                    placeholder={`Option ${i + 1}`}
                    placeholderTextColor={colors.muted}
                    value={opt}
                    onChangeText={(text) => {
                      const newOpts = [...options];
                      newOpts[i] = text;
                      setOptions(newOpts);
                    }}
                    style={{ flex: 1, backgroundColor: colors.background, borderRadius: 10, padding: 12, color: colors.foreground, fontSize: 14, borderWidth: 1, borderColor: colors.border }}
                  />
                  {options.length > 2 && (
                    <Pressable
                      onPress={() => setOptions(options.filter((_, idx) => idx !== i))}
                      style={({ pressed }) => [
                        { width: 40, alignItems: "center", justifyContent: "center", borderRadius: 10, backgroundColor: colors.error + "10" },
                        pressed && { opacity: 0.7 },
                      ]}
                    >
                      <IconSymbol name="xmark" size={14} color={colors.error} />
                    </Pressable>
                  )}
                </View>
              ))}
              <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
                <Pressable
                  onPress={() => setOptions([...options, ""])}
                  style={({ pressed }) => [{ flex: 1, padding: 10, borderRadius: 10, backgroundColor: colors.background, alignItems: "center", borderWidth: 1, borderColor: colors.border }, pressed && { opacity: 0.7 }]}
                >
                  <Text style={{ color: colors.primary, fontWeight: "600", fontSize: 13 }}>+ Option</Text>
                </Pressable>
                <Pressable
                  onPress={handleCreate}
                  style={({ pressed }) => [{ flex: 1, padding: 10, borderRadius: 10, backgroundColor: colors.primary, alignItems: "center" }, pressed && { opacity: 0.7 }]}
                >
                  <Text style={{ color: "#FFF", fontWeight: "600", fontSize: 13 }}>Créer</Text>
                </Pressable>
              </View>
            </View>
          </View>
        )}

        <View className="px-5">
          {polls.length === 0 ? (
            <View className="items-center py-12">
              <Text style={{ fontSize: 40, marginBottom: 8 }}>📊</Text>
              <Text className="text-muted text-center">Aucun sondage pour le moment</Text>
            </View>
          ) : (
            polls.map((poll) => {
              const totalVotes = poll.options.reduce((sum, o) => sum + o.votes.length, 0);
              const myVotedOption = poll.options.find((o) => o.votes.includes(userId));
              const isPollCreator = poll.createdBy === userId;
              return (
                <View key={poll.id} style={{ backgroundColor: colors.surface, borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: colors.border }}>
                  {/* Poll header */}
                  <View style={{ flexDirection: "row", alignItems: "flex-start", marginBottom: 10 }}>
                    <Text className="text-foreground font-bold text-sm" style={{ flex: 1 }}>{poll.question}</Text>
                    {(isAdmin || isPollCreator) && (
                      <Pressable
                        onPress={() => handleDeletePoll(poll.id)}
                        style={({ pressed }) => [
                          {
                            width: 28,
                            height: 28,
                            borderRadius: 8,
                            backgroundColor: colors.error + "10",
                            alignItems: "center",
                            justifyContent: "center",
                            marginLeft: 8,
                          },
                          pressed && { opacity: 0.7 },
                        ]}
                      >
                        <IconSymbol name="trash.fill" size={12} color={colors.error} />
                      </Pressable>
                    )}
                  </View>

                  {/* Options */}
                  {poll.options.map((opt) => {
                    const pct = totalVotes > 0 ? (opt.votes.length / totalVotes) * 100 : 0;
                    const voted = opt.votes.includes(userId);
                    return (
                      <Pressable
                        key={opt.id}
                        onPress={() => handleVote(poll.id, opt.id)}
                        style={({ pressed }) => [
                          {
                            marginBottom: 6,
                            borderRadius: 10,
                            overflow: "hidden",
                            borderWidth: 1,
                            borderColor: voted ? colors.primary : colors.border,
                          },
                          pressed && { opacity: 0.8 },
                        ]}
                      >
                        <View style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: `${pct}%`, backgroundColor: voted ? colors.primary + "20" : colors.border + "30" }} />
                        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 10 }}>
                          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, flex: 1 }}>
                            {voted && <IconSymbol name="checkmark.circle.fill" size={14} color={colors.primary} />}
                            <Text style={{ color: voted ? colors.primary : colors.foreground, fontWeight: voted ? "700" : "500", fontSize: 13 }}>
                              {opt.text}
                            </Text>
                          </View>
                          <Text style={{ color: colors.muted, fontSize: 12 }}>{opt.votes.length} ({Math.round(pct)}%)</Text>
                        </View>
                      </Pressable>
                    );
                  })}

                  {/* Footer with vote count + remove vote button */}
                  <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 6 }}>
                    <Text style={{ color: colors.muted, fontSize: 11 }}>
                      {totalVotes} vote{totalVotes !== 1 ? "s" : ""}
                    </Text>
                    {myVotedOption && (
                      <Pressable
                        onPress={() => handleRemoveMyVote(poll.id)}
                        style={({ pressed }) => [
                          {
                            flexDirection: "row",
                            alignItems: "center",
                            gap: 4,
                            paddingHorizontal: 10,
                            paddingVertical: 4,
                            borderRadius: 8,
                            backgroundColor: colors.error + "10",
                          },
                          pressed && { opacity: 0.7 },
                        ]}
                      >
                        <IconSymbol name="xmark" size={10} color={colors.error} />
                        <Text style={{ color: colors.error, fontSize: 11, fontWeight: "600" }}>Retirer mon vote</Text>
                      </Pressable>
                    )}
                  </View>
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
